import * as THREE from "three";

export interface ConceptSimulation {
  topic: string;
  explanation: string;
  threeJsCode: string;
  controlsGuide: string;
  interactiveParameters: Array<{
    name: string;
    label: string;
    type: string;
    min?: number;
    max?: number;
    step?: number;
    default: number | boolean;
  }>;
  isFallback?: boolean;
  fallbackError?: string;
}

export function classifySemanticQuery(prompt: string): "CONST_ORGANIC" | "CONST_PARTICLE_CLOUD" | "CONST_MOLECULAR" | "CONST_MATHEMATICAL" {
  const p = prompt.toLowerCase().trim();

  // Quantum Check: keywords containing "Quantum", "Orbitals", or "Electron Cloud" must NEVER be CONST_MOLECULAR
  const isQuantum = /quantum|orbitals?|electron[- ]?cloud/i.test(p);
  if (isQuantum) return "CONST_PARTICLE_CLOUD";

  // 1. CONST_ORGANIC: Biology, anatomy, organic structures
  const isOrganic = /dna|helix|chromos|gene|genetics|neuron|brain|axon|cell|membrane|mitochondria|biology|clinical|medical|biological|micro|anatomy|flesh|tissue|organelle|blood|heart|skull|bone|organ|lung|virus|bacteria|pathogen|anatomical|biological/i.test(p);
  if (isOrganic) return "CONST_ORGANIC";

  // 2. CONST_MOLECULAR: Chemical bonds, crystals, covalent networks (removed 'orbital' to prevent collision)
  const isMolecular = /chem|molecule|atom|h2o|co2|water|ethane|ethanol|bond|crystal|lattice|covalent|ionic|polymer|proton|neutron|catalyst|acid|base|reaction|compound|diamond|graphite|graphene|nacl|salt/i.test(p);
  if (isMolecular) return "CONST_MOLECULAR";

  // 3. CONST_MATHEMATICAL: Wave formulas, coordinate representations, manifolds, mechanics, kinematics
  const isMathematical = /math|geometry|calculus|fourier|harmonic|series|wave|interference|diffract|slit|optics|lens|snell|refract|mirror|ray|manifold|topolog|fractal|mobius|klein|vector|coordinate|matrix|sine|cosine|algebra|function|mechanics|pendulum|projectile|kinematics|dynamics|force|friction|pulley|gear|velocity|acceleration/i.test(p);
  if (isMathematical) return "CONST_MATHEMATICAL";

  // 4. CONST_PARTICLE_CLOUD: Space, clusters, fluids, or chaotic vortexes
  const isParticle = /space|galaxy|cosmos|star|planet|solar|gravit|orbit|kepler|astrophys|fluid|chaos|gas|nebula|cluster|cloud|smoke|particle|lorenz|attractor|field|flow|turbulence|liquid|vapor|wind|cyclone|weather/i.test(p);
  if (isParticle) return "CONST_PARTICLE_CLOUD";

  // Default fallback style split strictly without using unstyled mathematical fallback grid
  return p.length % 2 === 0 ? "CONST_ORGANIC" : "CONST_PARTICLE_CLOUD";
}

function enforceNeonAndLights(code: string): string {
  if (!code) return code;

  // 1. Replace THREE.DirectionalLight with THREE.PointLight
  let processed = code.replace(/new\s+THREE\.DirectionalLight/g, "new THREE.PointLight");

  // 2. Define the exact requested neon colors
  // Cyan: #00ffd2, Yellow: #ffff00, Orange: #ffaa00, Hot Pink: #ff0077
  const neonColors = ["#00ffd2", "#ffff00", "#ffaa00", "#ff0077"];

  // Replace hex colors
  processed = processed.replace(/(["'`])(#[0-9a-fA-F]{3,6})\1/g, (match, quote, hex) => {
    const lowerHex = hex.toLowerCase();

    // Dark/background colors - preserve or make extremely dark so the neon colors glow nicely
    if (/#000000|#0a0a0f|#1c1917|#0c0607|#0c0c0c|#050505|#111122|#151124|#222333|#2b2b4a|#12111d|#451c20|#3b0764|#111|#000|#0f111a|#151a30|#1e1e2d/i.test(lowerHex)) {
      return `${quote}#05050a${quote}`;
    }

    // Text color white / light gray - preserve for absolute legibility of HUD / UI text
    if (/#ffffff|#fff|#f8fafc|#f1f5f9|#e2e8f0|#cbd5e1/i.test(lowerHex)) {
      return match;
    }

    // Map other colors to the 4 strict neon colors using a stable hash of the color value
    let hash = 0;
    for (let i = 0; i < lowerHex.length; i++) {
      hash += lowerHex.charCodeAt(i);
    }
    const chosenColor = neonColors[hash % neonColors.length];
    return `${quote}${chosenColor}${quote}`;
  });

  // Also handle numeric 0xHEX color definitions in Three.js
  processed = processed.replace(/0x([0-9a-fA-F]{6}|[0-9a-fA-F]{3})/g, (match, hexVal) => {
    const lowerHex = hexVal.toLowerCase();
    
    // Skip dark/white numeric values if any
    if (/000000|ffffff|0a0a0f/i.test(lowerHex)) {
      return match;
    }

    const neonHexes = ["00ffd2", "ffff00", "ffaa00", "ff0077"];
    let hash = 0;
    for (let i = 0; i < lowerHex.length; i++) {
      hash += lowerHex.charCodeAt(i);
    }
    const chosenHex = neonHexes[hash % neonHexes.length];
    return `0x${chosenHex}`;
  });

  // 3. Inject AmbientLight and PointLights into the scene setup dynamically
  // This satisfies the condition "Add AmbientLight and PointLights to every scene"
  const lightsInjection = `
      const scene = new THREE.Scene();
      // Enforce ambient light and point lights
      const neonAmbientLight = new THREE.AmbientLight("#00ffd2", 0.4);
      scene.add(neonAmbientLight);
      const neonPointLight1 = new THREE.PointLight("#ff0077", 6, 80);
      neonPointLight1.position.set(10, 15, 10);
      scene.add(neonPointLight1);
      const neonPointLight2 = new THREE.PointLight("#ffaa00", 4, 80);
      neonPointLight2.position.set(-10, -5, -10);
      scene.add(neonPointLight2);
  `.trim();

  processed = processed.replace(/const\s+scene\s*=\s*new\s+THREE\.Scene\(\);/g, lightsInjection);

  return processed;
}

export function getFallbackResponse(prompt: string, errorMsg?: string): ConceptSimulation {
  const promptLower = prompt.toLowerCase();
  
  const classification = classifySemanticQuery(prompt);
  
  const isDna = /dna|helix|double helix|chromos|gene|genetics|rna|nucleic/i.test(promptLower);
  const isCellular = /neuron|brain|axon|cell|membrane|mitochondria|biology|clinical|medical|biological|micro|mitosis|meiosis|ribosome|heart|organelle|nucleus|cytoplasm|erythrocyte|leukocyte/i.test(promptLower);
  const isLattice = /lattice|crystal|grid|graphene|graphite|nacl|salt|diamond|silicon|cubic|fluorite|spinel|perovskite|structure/i.test(promptLower);
  const isQuantum = /quantum|orbitals?|electron[- ]?cloud|schrodinger|wavefunction|bohr|subshell|hydrogen/i.test(promptLower);
  const isChem = !isQuantum && !isLattice && /chem|molecule|atom|h2o|co2|water|ethane|ethanol|bond|covalent|benzene|glucose|methane|ch4|ammonia|chemical/i.test(promptLower);
  const isOrbit = /gravity|orbit|kepler|space|planet|solar|planetary|astrophys|black hole|singularity|cosmos|galaxy|milky way|nebula|star|constellation/i.test(promptLower);
  const isElectric = /electric|charge|coulomb|electrostatic|dipole|field|capacitor|voltage|potential/i.test(promptLower) && !/magnet|electromagnet/i.test(promptLower);
  const isMagnet = !isElectric && /magnet|field|magnetic|flux|dipole|electromag|lorentz|solenoid|induct/i.test(promptLower);
  const isFourier = /fourier|harmonic|synthes|series|square|triangle|sawtooth|gibbs|signal|frequency/i.test(promptLower);
  const isWave = !isFourier && /wave|optics|slit|interference|fringe|light|snell|diffract|refract|optics|reflection|lens|laser/i.test(promptLower);
  const isPendulum = /pendulum|chaos|coupled|oscillator|chaotic|mechanics|kinematics|projectile|trajectory|newton|dynamics|pulley|friction|torque|force/i.test(promptLower);
  const isMaritime = /maritime|marine|ship|vessel|navy|buoyancy|archimedes|metacentric|hydrostatics|stability|floating|keel|propulsion|navigation|rudder|ballast|hull|radar|sonar|bearing|heading|sail/i.test(promptLower);

  const title = prompt.trim()
    .split(/\s+/)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');

  let explanation = "";
  let controlsGuide = "";
  let interactiveParameters = [
    { name: "speed", label: "Simulation Speed", type: "slider", min: 0.1, max: 2.0, step: 0.1, default: 1.0 },
    { name: "sizeScale", label: "Visual Scale", type: "slider", min: 0.5, max: 2.0, step: 0.1, default: 1.0 },
    { name: "wireframe", label: "Structure Mode", type: "toggle", default: true }
  ];
  let fallbackCode = "";

  // ==========================================
  // BRANCH 0: QUANTUM PHYSICS ORBITAL CLOUD
  // ==========================================
  if (isQuantum) {
    explanation = `### Quantum Hydrogen Electron Cloud Orbitals
This scientific 3D model represents the probability density distribution of an electron in a hydrogen atom for **${title}**, governed by Quantum Mechanics and the Schrödinger Wave Equation.

#### The Schrödinger Wave Equation
The spatial wavefunction $\\psi_{n,l,m}(r, \\theta, \\phi)$ is solved in spherical polar coordinates as the product of a radial function $R_{n,l}(r)$ and the angular Spherical Harmonics $Y_l^m(\\theta, \\phi)$:

$$\\psi_{n,l,m}(r, \\theta, \\phi) = R_{n,l}(r) \\cdot Y_l^m(\\theta, \\phi)$$

The probability density $P(x,y,z) = |\\psi(r,\\theta,\\phi)|^2$ describes the likelihood of locating the electron within a given volume element.

#### Spherical Harmonics & Phase Color Coding
- **Probability distribution cloud**: Modeled using a high-density vertex array of points (THREE.Points) sampled through rejection-method probabilities.
- **Wavefunction Phase Phases**: The positive spatial phase ($\\psi > 0$) is colored in glowing Cyan/Teal, while the negative spatial phase ($\\psi < 0$) is colored in glowing Hot Pink/Magenta.
- **Strict Anti-Chemical Molecule Constraint**: Real quantum orbits do not consist of hard balls-and-sticks, crystal grids, or CPK atomic lattices. They exist as soft, continuous probability clouds. Grid coordinate helpers are kept to show quantum dimension space.`;

    controlsGuide = "Orbit to inspect 3D harmonic lobes. Slide 'Orbital Subshell' to toggle different orbitals, or adjust speed to rotate the wave phase.";

    interactiveParameters = [
      { name: "speed", label: "Rotation Speed", type: "slider", min: 0.1, max: 2.0, step: 0.1, default: 0.6 },
      { name: "sizeScale", label: "Cloud Scale", type: "slider", min: 0.5, max: 2.0, step: 0.1, default: 1.0 },
      { name: "subshell", label: "Orbital Subshell (0=s, 1=p, 2=d, 3=f)", type: "slider", min: 0, max: 3, step: 1, default: 1 }
    ];

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#030308");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 5, 12);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      scene.add(new THREE.AmbientLight("#111122", 1.5));
      const light = new THREE.PointLight("#00ffcc", 3, 30);
      light.position.set(5, 5, 5);
      scene.add(light);

      let rotationSpeed = currentParams.speed || 0.6;
      let scaleVal = currentParams.sizeScale || 1.0;
      let subshell = currentParams.subshell !== undefined ? Math.round(currentParams.subshell) : 1;

      const particleCount = 6000;
      const positions = new Float32Array(particleCount * 3);
      const colors = new Float32Array(particleCount * 3);

      function getProbability(r, theta, phi, modeIndex) {
        let R = 1.0;
        let Y = 1.0;
        let phase = 1.0;
        
        if (modeIndex === 0) {
          R = Math.exp(-r * 1.5);
          Y = 1.0;
          phase = 1.0;
        } else if (modeIndex === 1) {
          R = r * Math.exp(-r * 0.8);
          Y = Math.cos(theta);
          phase = Y;
        } else if (modeIndex === 2) {
          R = r * r * Math.exp(-r * 0.5);
          Y = 3 * Math.cos(theta) * Math.cos(theta) - 1;
          phase = Y;
        } else {
          R = r * r * r * Math.exp(-r * 0.4);
          Y = Math.cos(theta) * (5 * Math.cos(theta) * Math.cos(theta) - 3);
          phase = Y;
        }
        return { prob: R * R * Y * Y, phase };
      }

      function rebuildCloud(modeIndex) {
        let count = 0;
        let attempts = 0;
        const maxAttempts = 100000;
        
        while (count < particleCount && attempts < maxAttempts) {
          attempts++;
          const x = (Math.random() - 0.5) * 12;
          const y = (Math.random() - 0.5) * 12;
          const z = (Math.random() - 0.5) * 12;
          
          const r = Math.sqrt(x*x + y*y + z*z);
          if (r === 0 || r > 6.0) continue;
          
          const theta = Math.acos(y / r);
          const phi = Math.atan2(z, x);
          
          const { prob, phase } = getProbability(r, theta, phi, modeIndex);
          const maxProb = modeIndex === 0 ? 1.0 : (modeIndex === 1 ? 0.35 : (modeIndex === 2 ? 1.0 : 0.8));
          
          if (Math.random() * maxProb < prob) {
            positions[count * 3] = x;
            positions[count * 3 + 1] = y;
            positions[count * 3 + 2] = z;
            
            const col = new THREE.Color();
            if (phase >= 0) {
              col.setHSL(0.5 + Math.random() * 0.05, 1.0, 0.4 + prob * 0.4);
            } else {
              col.setHSL(0.9 + Math.random() * 0.05, 1.0, 0.4 + prob * 0.4);
            }
            colors[count * 3] = col.r;
            colors[count * 3 + 1] = col.g;
            colors[count * 3 + 2] = col.b;
            
            count++;
          }
        }
        
        for (let i = count; i < particleCount; i++) {
          positions[i * 3] = 0;
          positions[i * 3 + 1] = 0;
          positions[i * 3 + 2] = 0;
          colors[i * 3] = 0;
          colors[i * 3 + 1] = 0;
          colors[i * 3 + 2] = 0;
        }
      }

      rebuildCloud(subshell);

      const pCanvas = document.createElement("canvas");
      pCanvas.width = 16; pCanvas.height = 16;
      const pCtx = pCanvas.getContext("2d");
      const pGrad = pCtx.createRadialGradient(8, 8, 0, 8, 8, 8);
      pGrad.addColorStop(0, "rgba(255, 255, 255, 1)");
      pGrad.addColorStop(1, "rgba(255, 255, 255, 0)");
      pCtx.fillStyle = pGrad; pCtx.fillRect(0, 0, 16, 16);
      const pointTex = new THREE.CanvasTexture(pCanvas);

      const pGeo = new THREE.BufferGeometry();
      pGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
      pGeo.setAttribute("color", new THREE.BufferAttribute(colors, 3));

      const pMat = new THREE.PointsMaterial({
        size: 0.16,
        map: pointTex,
        vertexColors: true,
        transparent: true,
        opacity: 0.9,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      });

      const orbitalCloud = new THREE.Points(pGeo, pMat);
      scene.add(orbitalCloud);

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
      topCard.style.border = "1.5px solid #00ffcc"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelNode = document.createElement("div");
      labelNode.style.position = "absolute"; labelNode.style.zIndex = "10"; labelNode.style.pointerEvents = "none";
      labelNode.style.background = "rgba(10, 10, 15, 0.9)"; labelNode.style.border = "1.5px solid #ff3b77"; labelNode.style.borderRadius = "5px";
      labelNode.style.padding = "2px 6px"; labelNode.style.color = "#ffffff"; labelNode.style.fontSize = "9px"; labelNode.style.transform = "translate(-50%, -50%)";
      labelNode.textContent = "Spherical Harmonic Lobe";
      container.appendChild(labelNode);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime() * rotationSpeed;

        orbitalCloud.scale.set(scaleVal, scaleVal, scaleVal);
        orbitalCloud.rotation.y = elapsed * 0.4;
        orbitalCloud.rotation.x = elapsed * 0.15;

        const subshellName = subshell === 0 ? "1s (Spherical)" : (subshell === 1 ? "2p_z (Double Lobe)" : (subshell === 2 ? "3d_{z^2} (Torus Lobe)" : "4f (Multi-Lobe Octupole)"));
        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Quantum State: ' + subshellName + ' Probability Distribution</div>';

        const projV = new THREE.Vector3(0, subshell === 1 ? 1.8 : (subshell === 2 ? 1.5 : 2.0), 0);
        projV.applyMatrix4(orbitalCloud.matrixWorld).project(camera);
        labelNode.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
        labelNode.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) rotationSpeed = Number(p.speed);
          if (p.sizeScale !== undefined) scaleVal = Number(p.sizeScale);
          if (p.subshell !== undefined) {
            const nextSubshell = Math.round(Number(p.subshell));
            if (nextSubshell !== subshell) {
              subshell = nextSubshell;
              rebuildCloud(subshell);
              pGeo.attributes.position.needsUpdate = true;
              pGeo.attributes.color.needsUpdate = true;
            }
          }
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelNode && labelNode.parentNode) labelNode.parentNode.removeChild(labelNode);
          pointTex.dispose();
          pGeo.dispose();
          pMat.dispose();
        }
      };
    `;
  }

  // ==========================================
  // BRANCH 1: BIOLOGY DNA HELIX
  // ==========================================
  else if (isDna) {
    explanation = `### DNA Double Helix Structure
This biological representation visualizes the three-dimensional double-stranded spiral structure of **Deoxyribonucleic Acid (DNA)** for **${title}**.

#### Two-Helix Geometry
The double helix consists of two antiparallel polynucleotide chains running in $5' \\rightarrow 3'$ and $3' \\rightarrow 5'$ orientations. The helical paths are modeled mathematically by:

$$\\mathbf{r}_A(t) = \\left[ R \\cos(t), R \\sin(t), H \\cdot t \\right]$$
$$\\mathbf{r}_B(t) = \\left[ R \\cos(t + \\pi), R \\sin(t + \\pi), H \\cdot t \\right]$$

Where $R$ is the helical radius and $H$ regulates the pitch or vertical rise.

#### Base Pairs & Hydrogen Bonding
The two strands are stabilized by horizontal purine-pyrimidine base pairs oriented inward. Under the **Watson-Crick rules**:
- **Adenine** ($A$, Red) pairs with **Thymine** ($T$, Blue) via two hydrogen bonds: $A = T$
- **Guanine** ($G$, Yellow) pairs with **Cytosine** ($C$, Green) via three hydrogen bonds: $G \\equiv C$`;

    controlsGuide = "Orbit / drag to inspect the helical base-pair structures. Adjust speed to govern vertical spin rate.";
    
    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#030308");
      scene.fog = new THREE.FogExp2("#030308", 0.015);

      const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
      camera.position.set(0, 5, 22);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      // Organic bioluminescent lighting (Strictly NO dry grids or math coordinates overlays)
      const ambLight = new THREE.AmbientLight("#474787", 2.0);
      scene.add(ambLight);
      const pl1 = new THREE.PointLight("#00ffff", 5, 60); pl1.position.set(10, 15, 10); scene.add(pl1);
      const pl2 = new THREE.PointLight("#d100ec", 5, 60); pl2.position.set(-10, -5, -10); scene.add(pl2);

      let simSpeed = currentParams.speed || 1.0;
      let sizeScale = currentParams.sizeScale || 1.0;
      let showSecondary = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      const group = new THREE.Group();
      scene.add(group);

      const nPoints = 35;
      const nodesA = [];
      const nodesB = [];
      const rungs = [];

      const geomAtom = new THREE.SphereGeometry(0.5, 16, 16);
      const matBackbone = new THREE.MeshStandardMaterial({ color: "#8a5cf6", roughness: 0.1, metalness: 0.7 });

      for (let i = 0; i < nPoints; i++) {
        const sphereA = new THREE.Mesh(geomAtom, matBackbone);
        group.add(sphereA);
        nodesA.push(sphereA);

        const sphereB = new THREE.Mesh(geomAtom, matBackbone);
        group.add(sphereB);
        nodesB.push(sphereB);

        // Cylinder base rungs
        const cylGeo = new THREE.CylinderGeometry(0.12, 0.12, 1, 8);
        const col = i % 4 === 0 ? "#ef4444" : (i % 4 === 1 ? "#3b82f6" : (i % 4 === 2 ? "#eab308" : "#10b981"));
        const cylMat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.2, metalness: 0.7 });
        const rung = new THREE.Mesh(cylGeo, cylMat);
        group.add(rung);
        rungs.push({ mesh: rung, index: i });
      }

      function updateRung(mesh, start, end) {
        mesh.position.copy(new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5));
        const dir = new THREE.Vector3().subVectors(end, start).normalize();
        const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
        mesh.setRotationFromQuaternion(q);
        mesh.scale.set(1, start.distanceTo(end), 1);
      }

      const topCardDiv = document.createElement("div");
      topCardDiv.style.position = "absolute"; topCardDiv.style.top = "12px"; topCardDiv.style.left = "50%"; topCardDiv.style.transform = "translateX(-50%)";
      topCardDiv.style.zIndex = "10"; topCardDiv.style.pointerEvents = "none"; topCardDiv.style.background = "rgba(10, 10, 18, 0.8)";
      topCardDiv.style.border = "1.5px solid #8b5cf6"; topCardDiv.style.borderRadius = "10px"; topCardDiv.style.padding = "6px 12px";
      topCardDiv.style.fontFamily = "Inter, sans-serif"; topCardDiv.style.color = "white"; topCardDiv.style.fontSize = "11px"; topCardDiv.style.width = "max-content";
      container.appendChild(topCardDiv);

      const labelA = document.createElement("div");
      labelA.style.position = "absolute"; labelA.style.zIndex = "10"; labelA.style.pointerEvents = "none";
      labelA.style.background = "rgba(15, 23, 42, 0.85)"; labelA.style.border = "1.5px solid #ef4444"; labelA.style.borderRadius = "5px";
      labelA.style.padding = "2px 6px"; labelA.style.color = "#ffffff"; labelA.style.fontSize = "9px"; labelA.style.transform = "translate(-50%, -50%)";
      labelA.textContent = "Hydrogen Bond A-T";
      container.appendChild(labelA);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const tVal = clock.getElapsedTime() * simSpeed;
        group.rotation.y = tVal * 0.3;
        group.scale.set(sizeScale, sizeScale, sizeScale);

        const baseR = 3.6;
        for (let i = 0; i < nPoints; i++) {
          const helixTheta = (i / nPoints) * Math.PI * 4;
          const wobble = Math.sin(tVal + i * 0.3) * 0.25;
          const r = baseR + wobble;
          const y = (i - nPoints / 2) * 0.65;
          
          nodesA[i].position.set(Math.cos(helixTheta) * r, y, Math.sin(helixTheta) * r);
          nodesB[i].position.set(Math.cos(helixTheta + Math.PI) * r, y, Math.sin(helixTheta + Math.PI) * r);
          nodesB[i].visible = !!showSecondary;
        }

        rungs.forEach((r) => {
          const pA = nodesA[r.index].position;
          const pB = nodesB[r.index].position;
          if (showSecondary) {
            r.mesh.visible = true;
            updateRung(r.mesh, pA, pB);
          } else {
            r.mesh.visible = false;
          }
        });

        topCardDiv.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Watson-Crick Helix pairings active</div>';

        const v = new THREE.Vector3();
        if (nodesA[8]) {
          v.copy(nodesA[8].position).applyMatrix4(group.matrixWorld).project(camera);
          labelA.style.left = (v.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
          labelA.style.top = (-(v.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 12) + "px";
        }

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) simSpeed = Number(p.speed);
          if (p.sizeScale !== undefined) sizeScale = Number(p.sizeScale);
          if (p.wireframe !== undefined) showSecondary = !!p.wireframe;
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCardDiv && topCardDiv.parentNode) topCardDiv.parentNode.removeChild(topCardDiv);
          if (labelA && labelA.parentNode) labelA.parentNode.removeChild(labelA);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 2: BIOLOGY CELLULAR / NEURON
  // ==========================================
  else if (isCellular) {
    explanation = `### Bio-Molecular Cell & Neural Architecture
This biological rendering visualizes cellular morphology and somatic signal pathways for **${title}**.

#### Action Potential Conduction
Signal propagation across the cell soma follows the classical **Hodgkin-Huxley membrane dynamics**:

$$C_m \\frac{dV_m}{dt} = I_{\\text{ext}} - \\bar{g}_{\\text{Na}} m^3 h (V_m - E_{\\text{Na}}) - \\bar{g}_{\\text{K}} n^4 (V_m - E_{\\text{K}}) - g_L (V_m - E_L)$$

Where depolarizing ion currents traverse the lipid bilayer via embedded sodium & potassium channel pathways.

#### Morphology
Sub-cellular organelle structures, such as the cellular membrane and dendritic branching filaments, are constructed utilizing rich, organic volumetric meshes. Free of mechanical coordinate frames.`;

    controlsGuide = "Orbit to inspect somatic branching. The neon particle cascades represent propagating electrochemical action potential waves.";

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#04030a");
      scene.fog = new THREE.FogExp2("#04030a", 0.015);

      const camera = new THREE.PerspectiveCamera(65, width / height, 0.1, 1000);
      camera.position.set(0, 0, 18);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      // Wet-lab bioluminescent lights (NO dry Cartesian grids are permissible for organic cells!)
      scene.add(new THREE.AmbientLight("#3b0764", 1.5));
      const light1 = new THREE.PointLight("#00ffb7", 6, 40); light1.position.set(5, 5, 5); scene.add(light1);
      const light2 = new THREE.PointLight("#ef4444", 4, 40); light2.position.set(-5, -5, -5); scene.add(light2);

      let speed = currentParams.speed || 1.0;
      let scale = currentParams.sizeScale || 1.0;
      let showGlow = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      // Soma cell body
      const somaGeo = new THREE.IcosahedronGeometry(3, 2);
      const somaMat = new THREE.MeshStandardMaterial({
        color: "#d8b4fe",
        roughness: 0.1,
        metalness: 0.8,
        wireframe: true,
        transparent: true,
        opacity: 0.85
      });
      const soma = new THREE.Mesh(somaGeo, somaMat);
      scene.add(soma);

      // Branching Dendrites pathways
      const dendriteGroup = new THREE.Group();
      scene.add(dendriteGroup);

      const dendriticPaths = [];
      const nDendrites = 8;
      for (let d = 0; d < nDendrites; d++) {
        const theta = (d / nDendrites) * Math.PI * 2;
        const phi = (Math.random() - 0.5) * Math.PI * 0.5;
        const pathPoints = [];
        pathPoints.push(new THREE.Vector3(0, 0, 0));
        
        let startX = Math.cos(theta) * Math.cos(phi) * 3;
        let startY = Math.sin(phi) * 3;
        let startZ = Math.sin(theta) * Math.cos(phi) * 3;
        pathPoints.push(new THREE.Vector3(startX, startY, startZ));

        for (let j = 2; j < 5; j++) {
          pathPoints.push(new THREE.Vector3(
            startX * j * 0.7 + (Math.random() - 0.5) * 1.5,
            startY * j * 0.7 + (Math.random() - 0.5) * 1.5,
            startZ * j * 0.7 + (Math.random() - 0.5) * 1.5
          ));
        }

        const curve = new THREE.CatmullRomCurve3(pathPoints);
        const tubeGeo = new THREE.TubeGeometry(curve, 20, 0.12, 6, false);
        const tubeMat = new THREE.MeshStandardMaterial({ color: "#a855f7", transparent: true, opacity: 0.65 });
        const tube = new THREE.Mesh(tubeGeo, tubeMat);
        dendriteGroup.add(tube);
        dendriticPaths.push(curve);
      }

      // Action Potential Flow Particles
      const particleGeo = new THREE.SphereGeometry(0.18, 8, 8);
      const particleMat = new THREE.MeshBasicMaterial({ color: "#00ffb7" });
      const particles = [];

      for (let p = 0; p < 12; p++) {
        const mesh = new THREE.Mesh(particleGeo, particleMat);
        scene.add(mesh);
        particles.push({
          mesh: mesh,
          pathIndex: p % dendriticPaths.length,
          progress: Math.random()
        });
      }

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(12, 10, 20, 0.85)";
      topCard.style.border = "1.5px solid #a855f7"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelNode = document.createElement("div");
      labelNode.style.position = "absolute"; labelNode.style.zIndex = "10"; labelNode.style.pointerEvents = "none";
      labelNode.style.background = "rgba(10, 10, 15, 0.85)"; labelNode.style.border = "1.5px solid #00ffb7"; labelNode.style.borderRadius = "5px";
      labelNode.style.padding = "2px 6px"; labelNode.style.color = "#ffffff"; labelNode.style.fontSize = "9px"; labelNode.style.transform = "translate(-50%, -50%)";
      labelNode.textContent = "Soma / Cell Body";
      container.appendChild(labelNode);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime() * speed;

        soma.rotation.y = elapsed * 0.2;
        soma.rotation.z = elapsed * 0.1;
        const breath = 1.0 + Math.sin(elapsed * 1.5) * 0.08;
        soma.scale.set(scale * breath, scale * breath, scale * breath);

        dendriteGroup.rotation.y = elapsed * 0.05;
        dendriteGroup.scale.set(scale, scale, scale);

        particles.forEach((p) => {
          p.progress += 0.015 * speed;
          if (p.progress > 1.0) p.progress = 0;
          const curve = dendriticPaths[p.pathIndex];
          const pos = curve.getPointAt(p.progress);
          
          p.mesh.position.copy(pos).applyMatrix4(dendriteGroup.matrixWorld);
          p.mesh.visible = showGlow;
        });

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Cell Membrane potential: -70 mV active</div>';

        const projV = new THREE.Vector3();
        projV.copy(soma.position).project(camera);
        labelNode.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
        labelNode.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 25) + "px";

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) speed = Number(p.speed);
          if (p.sizeScale !== undefined) scale = Number(p.sizeScale);
          if (p.wireframe !== undefined) {
            showGlow = !!p.wireframe;
            somaMat.wireframe = !showGlow;
          }
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelNode && labelNode.parentNode) labelNode.parentNode.removeChild(labelNode);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 3: CRYSTALLINE LATTICE ATOMIC GEOMETRY
  // ==========================================
  else if (isLattice) {
    explanation = `### Crystalline Lattice & Atomic Geometry
This molecular mechanics laboratory visualizes three-dimensional crystalline grids and packing vectors for **\${title}**.

#### Bravais Lattices and Bravais Coordinates
Crystal structures are characterized by standard repeating unit cell vectors $\\mathbf{a}$, $\\mathbf{b}$, and $\\mathbf{c}$. Under **Bragg's Law**, coherent X-ray diffractions satisfy:

$$2d \\sin\\theta = n\\lambda$$

Where $d$ represents the interplanar spacing of lattice planes, and $\\lambda$ is the incident wavelength.

#### Ionic Grid Configuration
The ionic model arranges alternating Sodium ($\\text{Na}^+$, Purple) and Chlorine ($\\text{Cl}^-$, Green) elements structured in a body/face-centered cubic lattice matrix:
- **Sodium Ions**: Grouped smaller radii $\\approx 0.7\\text{ Å}$
- **Chlorine Ions**: Grouped larger radii $\\approx 1.1\\text{ Å}$
- **Static Coordination**: Alternating 6-coordinate lattice joints, connected via ionic force cylinders.`;

    controlsGuide = "Orbit to inspect 3D coordination joints. The spacing slider contracts/expands repeating vector cells dynamically.";

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#07070d");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(5, 5, 12);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      scene.add(new THREE.AmbientLight("#12111d", 1.5));
      const light1 = new THREE.DirectionalLight("#a855f7", 2.2); light1.position.set(10, 15, 10); scene.add(light1);
      const light2 = new THREE.DirectionalLight("#10b981", 1.2); light2.position.set(-10, -5, -10); scene.add(light2);

      let simSpeed = currentParams.speed || 1.0;
      let spacing = currentParams.sizeScale || 1.0;
      let showBonds = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      const latticeGroup = new THREE.Group();
      scene.add(latticeGroup);

      const latticePoints = [];
      const bondMeshes = [];

      // Construct a 3x3x3 cubic NaCl Crystal Lattice with alternating sodium (purple) and chlorine (green)
      for (let x = -1; x <= 1; x++) {
        for (let y = -1; y <= 1; y++) {
          for (let z = -1; z <= 1; z++) {
            const isSodium = (x + y + z) % 2 === 0;
            const name = isSodium ? "Sodium (Na+)" : "Chlorine (Cl-)";
            const col = isSodium ? "#a855f7" : "#10b981";
            const rad = isSodium ? 0.45 : 0.7; // scaled beautifully
            
            const atomGeo = new THREE.SphereGeometry(rad, 24, 24);
            const atomMat = new THREE.MeshStandardMaterial({
              color: col,
              roughness: 0.1,
              metalness: 0.6,
              clearcoat: 1.0
            });
            const mesh = new THREE.Mesh(atomGeo, atomMat);
            latticeGroup.add(mesh);
            
            latticePoints.push({
              mesh: mesh,
              initialPos: new THREE.Vector3(x * 2.2, y * 2.2, z * 2.2),
              seed: Math.random() * 100,
              isSodium: isSodium
            });
          }
        }
      }

      // Pre-connect adjacent bonds
      for (let i = 0; i < latticePoints.length; i++) {
        for (let j = i + 1; j < latticePoints.length; j++) {
          const pA = latticePoints[i].initialPos;
          const pB = latticePoints[j].initialPos;
          const dstSq = pA.distanceToSquared(pB);
          // Directly adjacent nodes are 2.2 units apart (2.2^2 = 4.84)
          if (dstSq > 4.0 && dstSq < 5.5) {
            const bondGeo = new THREE.CylinderGeometry(0.08, 0.08, 1, 12);
            const bondMat = new THREE.MeshStandardMaterial({ color: "#2d2d3d", roughness: 0.5 });
            const mesh = new THREE.Mesh(bondGeo, bondMat);
            latticeGroup.add(mesh);
            bondMeshes.push({ mesh: mesh, from: i, to: j });
          }
        }
      }

      function updateBond(mesh, pA, pB) {
        mesh.position.copy(new THREE.Vector3().addVectors(pA, pB).multiplyScalar(0.5));
        const dir = new THREE.Vector3().subVectors(pB, pA).normalize();
        const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
        mesh.setRotationFromQuaternion(q);
        mesh.scale.set(1, pA.distanceTo(pB), 1);
      }

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
      topCard.style.border = "1.5px solid #8b5cf6"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelA = document.createElement("div");
      labelA.style.position = "absolute"; labelA.style.zIndex = "10"; labelA.style.pointerEvents = "none";
      labelA.style.background = "rgba(10, 10, 15, 0.85)"; labelA.style.border = "1.5px solid #a855f7"; labelA.style.borderRadius = "5px";
      labelA.style.padding = "2px 6px"; labelA.style.color = "#ffffff"; labelA.style.fontSize = "9px"; labelA.style.transform = "translate(-50%, -50%)";
      labelA.textContent = "Sodium Core (Na+)";
      container.appendChild(labelA);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime();

        latticeGroup.rotation.y = elapsed * 0.12 * simSpeed;
        latticeGroup.rotation.x = elapsed * 0.05 * simSpeed;

        // Position atoms according to visual space spacing scale and trigger subtle thermal vibration
        latticePoints.forEach((lp) => {
          const thermalNoise = Math.sin(elapsed * 8.0 * simSpeed + lp.seed) * 0.05 * simSpeed;
          const scalePos = lp.initialPos.clone().multiplyScalar(spacing).addScalar(thermalNoise);
          lp.mesh.position.copy(scalePos);
        });

        // Align bonds dynamically
        bondMeshes.forEach((bm) => {
          bm.mesh.visible = showBonds;
          if (showBonds) {
            updateBond(bm.mesh, latticePoints[bm.from].mesh.position, latticePoints[bm.to].mesh.position);
          }
        });

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Coordination System: Alternating 6:6 Cubic lattice</div>';

        const projV = new THREE.Vector3();
        if (latticePoints[13]) { // Central Sodium atom in the 27-atom grid (index 13)
          projV.copy(latticePoints[13].mesh.position).applyMatrix4(latticeGroup.matrixWorld).project(camera);
          labelA.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
          labelA.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";
        }

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) simSpeed = Number(p.speed);
          if (p.sizeScale !== undefined) spacing = Number(p.sizeScale);
          if (p.wireframe !== undefined) showBonds = !!p.wireframe;
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelA && labelA.parentNode) labelA.parentNode.removeChild(labelA);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 4: CHEMISTRY CPK MOLECULAR BALL-AND-STICK
  // ==========================================
  else if (isChem) {
    explanation = `### CPK Ball-and-Stick Molecular Chemistry
This molecular simulation maps the atomic configuration and cylinder covalent bonds for **${title}**.

#### Atomic CPK Radius Conventions
Atoms are sized proportionally to their mechanical **van der Waals radii** and color-coded explicitly under textbook IUPAC conventions:
- **Carbon** ($C$, Slate Grey): $\\approx 1.7\\text{ Å}$ radius
- **Oxygen** ($O$, Crimson Red): $\\approx 1.5\\text{ Å}$ radius
- **Hydrogen** ($H$, Clean White): $\\approx 1.2\\text{ Å}$ radius
- **Nitrogen** ($N$, Electric Blue): $\\approx 1.55\\text{ Å}$ radius

#### Chemical Potentials & Covalent Cylinder Bonds
Atomic centers are linked via rigorous rigid covalent cylinder bonds representing shared electron density. Covalent interaction energies are calculated as:

$$V_{\\text{bond}} = \\sum \\frac{1}{2} k_b (r - r_0)^2$$

Where $k_b$ is the bond spring stretch constant and $r_0$ is the molecular equilibrium separation.`;

    controlsGuide = "Orbit to inspect covalent geometry. Toggle structure mode to switch between atomic space-filling or ball-and-stick renderings.";

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#0c0d12");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 4, 15);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      scene.add(new THREE.AmbientLight("#222333", 1.0));
      const light1 = new THREE.DirectionalLight("#ffffff", 2.0); light1.position.set(10, 10, 10); scene.add(light1);
      const light2 = new THREE.DirectionalLight("#3b82f6", 1.0); light2.position.set(-10, -5, -10); scene.add(light2);

      let simSpeed = currentParams.speed || 1.0;
      let sizeScale = currentParams.sizeScale || 1.0;
      let stickMode = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      // Generate layout molecules based on user query
      const moleculeGroup = new THREE.Group();
      scene.add(moleculeGroup);

      const atomList = [];
      const bondsList = [];

      // Determine matching structure: H2O vs CO2 vs Methane (CH4) vs Glucose/Benzene hex-ring
      const isWater = /h2o|water/i.test("${promptLower}");
      const isCO2 = /co2|carbon dioxide/i.test("${promptLower}");
      const isMethane = /ch4|methane/i.test("${promptLower}");

      if (isWater) {
        // H2O
        atomList.push({ name: "Oxygen (O)", type: "O", pos: new THREE.Vector3(0, 0, 0), color: "#ef4444", radius: 1.4 });
        atomList.push({ name: "Hydrogen (H1)", type: "H", pos: new THREE.Vector3(-1.6, 1.2, 0), color: "#f8fafc", radius: 0.95 });
        atomList.push({ name: "Hydrogen (H2)", type: "H", pos: new THREE.Vector3(1.6, 1.2, 0), color: "#f8fafc", radius: 0.95 });
        bondsList.push({ from: 0, to: 1 });
        bondsList.push({ from: 0, to: 2 });
      } else if (isCO2) {
        // CO2
        atomList.push({ name: "Carbon (C)", type: "C", pos: new THREE.Vector3(0, 0, 0), color: "#334155", radius: 1.5 });
        atomList.push({ name: "Oxygen (O1)", type: "O", pos: new THREE.Vector3(-2.2, 0, 0), color: "#ef4444", radius: 1.4 });
        atomList.push({ name: "Oxygen (O2)", type: "O", pos: new THREE.Vector3(2.2, 0, 0), color: "#ef4444", radius: 1.4 });
        bondsList.push({ from: 0, to: 1 });
        bondsList.push({ from: 0, to: 2 });
      } else if (isMethane) {
        // CH4
        atomList.push({ name: "Carbon (C)", type: "C", pos: new THREE.Vector3(0, 0, 0), color: "#334155", radius: 1.5 });
        atomList.push({ name: "Hydrogen (H1)", type: "H", pos: new THREE.Vector3(1.4, 1.4, 1.4), color: "#f8fafc", radius: 0.95 });
        atomList.push({ name: "Hydrogen (H2)", type: "H", pos: new THREE.Vector3(-1.4, -1.4, 1.4), color: "#f8fafc", radius: 0.95 });
        atomList.push({ name: "Hydrogen (H3)", type: "H", pos: new THREE.Vector3(-1.4, 1.4, -1.4), color: "#f8fafc", radius: 0.95 });
        atomList.push({ name: "Hydrogen (H4)", type: "H", pos: new THREE.Vector3(1.4, -1.4, -1.4), color: "#f8fafc", radius: 0.95 });
        bondsList.push({ from: 0, to: 1 });
        bondsList.push({ from: 0, to: 2 });
        bondsList.push({ from: 0, to: 3 });
        bondsList.push({ from: 0, to: 4 });
      } else {
        // Hex Polymer Benzene Ring (Beautiful Default Molecular representation query!)
        for (let i = 0; i < 6; i++) {
          const theta = (i / 6) * Math.PI * 2;
          const x = Math.cos(theta) * 2.5;
          const z = Math.sin(theta) * 2.5;
          atomList.push({ name: "Carbon (C" + (i+1) + ")", type: "C", pos: new THREE.Vector3(x, 0, z), color: "#334155", radius: 1.5 });
          
          const hX = Math.cos(theta) * 4.0;
          const hZ = Math.sin(theta) * 4.0;
          atomList.push({ name: "Hydrogen (H" + (i+1) + ")", type: "H", pos: new THREE.Vector3(hX, 0, hZ), color: "#f8fafc", radius: 0.95 });
          
          bondsList.push({ from: i * 2, to: i * 2 + 1 }); // Carbon to Hydrogen
          bondsList.push({ from: i * 2, to: ((i + 1) % 6) * 2 }); // Carbon to Carbon
        }
      }

      const atomMeshes = [];
      const bondMeshes = [];

      atomList.forEach((a) => {
        const atomGeo = new THREE.SphereGeometry(a.radius, 32, 32);
        const atomMat = new THREE.MeshStandardMaterial({
          color: a.color,
          roughness: 0.1,
          metalness: 0.6,
          clearcoat: 1.0
        });
        const mesh = new THREE.Mesh(atomGeo, atomMat);
        mesh.position.copy(a.pos);
        moleculeGroup.add(mesh);
        atomMeshes.push(mesh);
      });

      bondsList.forEach((b) => {
        const bondGeo = new THREE.CylinderGeometry(0.2, 0.2, 1, 16);
        const bondMat = new THREE.MeshStandardMaterial({ color: "#e2e8f0", roughness: 0.3 });
        const mesh = new THREE.Mesh(bondGeo, bondMat);
        moleculeGroup.add(mesh);
        bondMeshes.push({ mesh: mesh, from: b.from, to: b.to });
      });

      function updateBond(mesh, pA, pB) {
        mesh.position.copy(new THREE.Vector3().addVectors(pA, pB).multiplyScalar(0.5));
        const dir = new THREE.Vector3().subVectors(pB, pA).normalize();
        const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
        mesh.setRotationFromQuaternion(q);
        mesh.scale.set(1, pA.distanceTo(pB), 1);
      }

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 15, 30, 0.85)";
      topCard.style.border = "1.5px solid #3b82f6"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelA = document.createElement("div");
      labelA.style.position = "absolute"; labelA.style.zIndex = "10"; labelA.style.pointerEvents = "none";
      labelA.style.background = "rgba(10, 10, 15, 0.9)"; labelA.style.border = "1.5px solid #ef4444"; labelA.style.borderRadius = "5px";
      labelA.style.padding = "2px 6px"; labelA.style.color = "#ffffff"; labelA.style.fontSize = "9px"; labelA.style.transform = "translate(-50%, -50%)";
      labelA.textContent = isCO2 || isWater ? atomList[0].name : "Carbon (C1)";
      container.appendChild(labelA);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime() * simSpeed;

        moleculeGroup.rotation.y = elapsed * 0.25;
        moleculeGroup.rotation.z = elapsed * 0.1;
        moleculeGroup.scale.set(sizeScale, sizeScale, sizeScale);

        // Adjust dimensions dynamically depending on atom model mode
        atomMeshes.forEach((mesh, index) => {
          const originalRad = atomList[index].radius;
          const targetRad = stickMode ? originalRad : originalRad * 1.6;
          mesh.scale.setScalar(targetRad / originalRad);
        });

        bondMeshes.forEach((b) => {
          if (stickMode) {
            b.mesh.visible = true;
            updateBond(b.mesh, atomMeshes[b.from].position, atomMeshes[b.to].position);
          } else {
            b.mesh.visible = false;
          }
        });

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">CPK Element Colors: Grey(C) | Red(O) | White(H)</div>';

        const projV = new THREE.Vector3();
        if (atomMeshes[0]) {
          projV.copy(atomMeshes[0].position).applyMatrix4(moleculeGroup.matrixWorld).project(camera);
          labelA.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
          labelA.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 25) + "px";
        }

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) simSpeed = Number(p.speed);
          if (p.sizeScale !== undefined) sizeScale = Number(p.sizeScale);
          if (p.wireframe !== undefined) stickMode = !!p.wireframe;
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelA && labelA.parentNode) labelA.parentNode.removeChild(labelA);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 4: ASTROPHYSICS / KEPLER LAW ORBITS
  // ==========================================
  else if (isOrbit) {
    explanation = `### Kepler Astronomical System Laws
This physics simulation tracks the planetary orbits and gravitation trajectories for **${title}**.

#### Elliptical Planetary Vectors
Orbits trace precise Kepler ellipses dictated by central Newtonian attraction forces:

$$\\mathbf{F} = -G \\frac{M m}{r^2} \\hat{\\mathbf{r}}$$

#### Kepler's Harmonic Harmonizer
The orbital period $T$ and semi-major axis $a$ satisfy Kepler's law:

$$T^2 = \\frac{4\\pi^2}{G M} a^3 \\propto a^3$$

Where $M$ is solar mass, verifying planetary speeds increase as planets near perihelion.`;

    controlsGuide = "Orbit / Drag to inspect the Cartesian planetary grid and elliptical path tracks. Adjust speed to govern orbital rate.";

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#020208");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 15, 25);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      scene.add(new THREE.AmbientLight("#111", 1.0));
      const sunLight = new THREE.PointLight("#ffaa00", 10, 100);
      scene.add(sunLight);

      let speedVal = currentParams.speed || 1.0;
      let scaleVal = currentParams.sizeScale || 1.0;
      let showPaths = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      // Direct Central Solar Star
      const sunGeo = new THREE.SphereGeometry(2.0, 32, 32);
      const sunMat = new THREE.MeshBasicMaterial({ color: "#facc15" });
      const sun = new THREE.Mesh(sunGeo, sunMat);
      scene.add(sun);

      // Orbital Satellites configuration
      const planets = [
        { name: "Inner Satellite", radius: 5, speed: 2.2, size: 0.4, color: "#38bdf8", angle: 0 },
        { name: "Outer Boundary", radius: 9, speed: 1.2, size: 0.6, color: "#f97316", angle: Math.PI }
      ];

      const planetMeshes = [];
      const orbitLines = [];

      planets.forEach((p) => {
        // Render planet sphere
        const pGeo = new THREE.SphereGeometry(p.size, 16, 16);
        const pMat = new THREE.MeshStandardMaterial({ color: p.color, roughness: 0.5 });
        const mesh = new THREE.Mesh(pGeo, pMat);
        scene.add(mesh);
        planetMeshes.push({ mesh: mesh, meta: p });

        // Trajectory orbits path line helper
        const pathGeo = new THREE.RingGeometry(p.radius - 0.05, p.radius + 0.05, 64);
        const pathMat = new THREE.MeshBasicMaterial({ color: p.color, side: THREE.DoubleSide });
        const pathLine = new THREE.Mesh(pathGeo, pathMat);
        pathLine.rotation.x = Math.PI / 2;
        scene.add(pathLine);
        orbitLines.push(pathLine);
      });

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
      topCard.style.border = "1.5px solid #eab308"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelA = document.createElement("div");
      labelA.style.position = "absolute"; labelA.style.zIndex = "10"; labelA.style.pointerEvents = "none";
      labelA.style.background = "rgba(10, 10, 15, 0.85)"; labelA.style.border = "1.5px solid #38bdf8"; labelA.style.borderRadius = "5px";
      labelA.style.padding = "2px 6px"; labelA.style.color = "#ffffff"; labelA.style.fontSize = "9px"; labelA.style.transform = "translate(-50%, -50%)";
      labelA.textContent = "Inner Planet Perihelion";
      container.appendChild(labelA);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime() * speedVal;

        planetMeshes.forEach((pm) => {
          pm.meta.angle += 0.02 * pm.meta.speed * speedVal;
          const dist = pm.meta.radius * scaleVal;
          pm.mesh.position.set(Math.cos(pm.meta.angle) * dist, 0, Math.sin(pm.meta.angle) * dist);
          pm.mesh.scale.setScalar(scaleVal);
        });

        orbitLines.forEach((ol, index) => {
          ol.visible = showPaths;
          ol.scale.setScalar(scaleVal);
        });

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Kepler Vector Period T^2 proportional to a^3</div>';

        const projV = new THREE.Vector3();
        if (planetMeshes[0]) {
          projV.copy(planetMeshes[0].mesh.position).project(camera);
          labelA.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
          labelA.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";
        }

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) speedVal = Number(p.speed);
          if (p.sizeScale !== undefined) scaleVal = Number(p.sizeScale);
          if (p.wireframe !== undefined) showPaths = !!p.wireframe;
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelA && labelA.parentNode) labelA.parentNode.removeChild(labelA);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 4.5: PHYSICS ELECTRIC DIPOLE AND FIELD LINES
  // ==========================================
  else if (isElectric) {
    explanation = `### Electric Dipole Field and Potential
This electrodynamics laboratory simulates the electric field lines and potentials of an **Electric Dipole** composed of two equal and opposite charges $+q$ and $-q$ separated by a distance $d$.

#### Dipole Electric Potential
The electrostatic potential $V(\\mathbf{r})$ at a position vector $\\mathbf{r}$ relative to the dipole center is calculated using Coulomb's law:

$$V(\\mathbf{r}) = \\frac{1}{4\\pi\\varepsilon_0} \\left( \\frac{q}{r_+} - \\frac{q}{r_-} \\right)$$

For large distances ($r \\gg d$), this potential simplifies using the electric dipole moment vector $\\mathbf{p} = q\\mathbf{d}$:

$$V(\\mathbf{r}) \\approx \\frac{1}{4\\pi\\varepsilon_0} \\frac{\\mathbf{p} \\cdot \\hat{\\mathbf{r}}}{r^2} = \\frac{1}{4\\pi\\varepsilon_0} \\frac{p \\cos\\theta}{r^2}$$

#### Electrostatic Field Lines
The electric field vector $\\mathbf{E}$ is the negative gradient of the potential ($\\mathbf{E} = -\\nabla V$). Field lines emerge radially from the **Positive Charge** (bright red $+q$) and converge onto the **Negative Charge** (bright yellow $-q$). Glowing tracer particles (bright cyan) flow continuously along these lines to map out the force trajectories.`;

    controlsGuide = "Orbit to examine flow directions. Particles stream from the Positive Charge (Bright Red, +q) to the Negative Charge (Bright Yellow, -q). Adjust charge values and distance dynamically.";

    interactiveParameters = [
      { name: "speed", label: "Simulation Speed", type: "slider", min: 0.1, max: 2.0, step: 0.1, default: 1.0 },
      { name: "sizeScale", label: "Visual Scale", type: "slider", min: 0.5, max: 2.0, step: 0.1, default: 1.0 },
      { name: "chargeMag", label: "Charge Magnitude (q)", type: "slider", min: 1.0, max: 5.0, step: 0.5, default: 3.0 },
      { name: "separation", label: "Dipole Separation (d)", type: "slider", min: 2.0, max: 8.0, step: 0.5, default: 5.0 },
      { name: "wireframe", label: "Show Field Lines", type: "toggle", default: true }
    ];

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#020205");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 8, 16);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      // Ambient and directional lighting
      scene.add(new THREE.AmbientLight("#0f111a", 0.5));
      const dirLight = new THREE.DirectionalLight("#ffffff", 0.8);
      dirLight.position.set(5, 12, 5);
      scene.add(dirLight);

      let speed = currentParams.speed || 1.0;
      let scale = currentParams.sizeScale || 1.0;
      let chargeMag = currentParams.chargeMag || 3.0;
      let separation = currentParams.separation || 5.0;
      let showLines = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      const dipoleGroup = new THREE.Group();
      scene.add(dipoleGroup);

      // Positive charge mesh: bright red #ff3366 with emissive glow
      const posGeom = new THREE.SphereGeometry(0.6, 32, 32);
      const posMat = new THREE.MeshStandardMaterial({
        color: "#ff3366",
        emissive: "#ff3366",
        emissiveIntensity: 0.6,
        roughness: 0.1,
        metalness: 0.1
      });
      const posMesh = new THREE.Mesh(posGeom, posMat);
      dipoleGroup.add(posMesh);

      // Negative charge mesh: bright yellow #ffff00 with emissive glow
      const negGeom = new THREE.SphereGeometry(0.6, 32, 32);
      const negMat = new THREE.MeshStandardMaterial({
        color: "#ffff00",
        emissive: "#ffff00",
        emissiveIntensity: 0.6,
        roughness: 0.1,
        metalness: 0.1
      });
      const negMesh = new THREE.Mesh(negGeom, negMat);
      dipoleGroup.add(negMesh);

      // Add PointLights to charges for exceptional visibility!
      const posLight = new THREE.PointLight("#ff3366", 3, 15);
      posMesh.add(posLight);

      const negLight = new THREE.PointLight("#ffff00", 3, 15);
      negMesh.add(negLight);

      let curvesList = [];
      let curvesMeshes = [];
      let dots = [];

      function rebuildFieldLines() {
        curvesMeshes.forEach(mesh => scene.remove(mesh));
        curvesMeshes = [];
        curvesList = [];

        const halfSep = separation / 2;
        posMesh.position.set(halfSep, 0, 0);
        negMesh.position.set(-halfSep, 0, 0);

        const numRings = 4;
        const linesPerRing = 8;
        
        for (let ring = 0; ring < numRings; ring++) {
          const bowFactor = 1.0 + ring * 1.2;
          for (let l = 0; l < linesPerRing; l++) {
            const angle = (l / linesPerRing) * Math.PI * 2;
            const cos = Math.cos(angle);
            const sin = Math.sin(angle);

            const pathPoints = [
              new THREE.Vector3(halfSep, 0, 0),
              new THREE.Vector3(halfSep * 0.6, bowFactor * 0.7 * cos, bowFactor * 0.7 * sin),
              new THREE.Vector3(0, bowFactor * 1.1 * cos, bowFactor * 1.1 * sin),
              new THREE.Vector3(-halfSep * 0.6, bowFactor * 0.7 * cos, bowFactor * 0.7 * sin),
              new THREE.Vector3(-halfSep, 0, 0)
            ];

            const curve = new THREE.CatmullRomCurve3(pathPoints);
            curvesList.push(curve);

            const tubeGeo = new THREE.TubeGeometry(curve, 40, 0.04, 8, false);
            const tubeMat = new THREE.MeshStandardMaterial({
              color: "#00ffd2",
              transparent: true,
              opacity: 0.28,
              emissive: "#00ffd2",
              emissiveIntensity: 0.2,
              roughness: 0.1
            });
            const tube = new THREE.Mesh(tubeGeo, tubeMat);
            scene.add(tube);
            curvesMeshes.push(tube);
          }
        }

        dots.forEach(d => {
          d.curveIndex = Math.floor(Math.random() * curvesList.length);
        });
      }

      // Tracer particles: bright cyan #00ffd2
      const dotGeo = new THREE.SphereGeometry(0.12, 16, 16);
      const dotMat = new THREE.MeshStandardMaterial({
        color: "#00ffd2",
        emissive: "#00ffd2",
        emissiveIntensity: 0.8,
        roughness: 0.1
      });

      for (let d = 0; d < 35; d++) {
        const dot = new THREE.Mesh(dotGeo, dotMat);
        scene.add(dot);
        dots.push({
          mesh: dot,
          curveIndex: d % 16,
          pos: Math.random()
        });
      }

      rebuildFieldLines();

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.75)";
      topCard.style.backdropFilter = "blur(8px)"; topCard.style.webkitBackdropFilter = "blur(8px)";
      topCard.style.border = "1.5px solid #00ffd2"; topCard.style.borderRadius = "10px"; topCard.style.padding = "8px 16px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      topCard.style.boxShadow = "0 6px 20px rgba(0,0,0,0.5)";
      container.appendChild(topCard);

      const labelA = document.createElement("div");
      labelA.style.position = "absolute"; labelA.style.zIndex = "10"; labelA.style.pointerEvents = "none";
      labelA.style.background = "rgba(10, 10, 15, 0.85)"; labelA.style.border = "1.5px solid #ff3366"; labelA.style.borderRadius = "5px";
      labelA.style.padding = "2px 6px"; labelA.style.color = "#ff3366"; labelA.style.fontWeight = "600"; labelA.style.fontSize = "10px"; labelA.style.transform = "translate(-50%, -50%)";
      labelA.style.fontFamily = "monospace";
      labelA.textContent = "Positive (+q)";
      container.appendChild(labelA);

      const labelB = document.createElement("div");
      labelB.style.position = "absolute"; labelB.style.zIndex = "10"; labelB.style.pointerEvents = "none";
      labelB.style.background = "rgba(10, 10, 15, 0.85)"; labelB.style.border = "1.5px solid #ffff00"; labelB.style.borderRadius = "5px";
      labelB.style.padding = "2px 6px"; labelB.style.color = "#ffff00"; labelB.style.fontWeight = "600"; labelB.style.fontSize = "10px"; labelB.style.transform = "translate(-50%, -50%)";
      labelB.style.fontFamily = "monospace";
      labelB.textContent = "Negative (-q)";
      container.appendChild(labelB);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime() * speed;

        dipoleGroup.rotation.y = elapsed * 0.15;

        posMesh.scale.set(scale, scale, scale);
        negMesh.scale.set(scale, scale, scale);

        curvesMeshes.forEach((cm) => {
          cm.visible = showLines;
          cm.rotation.y = dipoleGroup.rotation.y;
          cm.scale.set(scale, scale, scale);
        });

        dots.forEach((d) => {
          d.pos += 0.008 * speed;
          if (d.pos > 1.0) d.pos = 0;
          if (curvesList[d.curveIndex]) {
            const pt = curvesList[d.curveIndex].getPointAt(d.pos);
            d.mesh.position.copy(pt).applyAxisAngle(new THREE.Vector3(0, 1, 0), dipoleGroup.rotation.y).multiplyScalar(scale);
            d.mesh.scale.set(scale, scale, scale);
            d.mesh.visible = showLines;
          }
        });

        const qVal = (typeof chargeMag === "number" && !isNaN(chargeMag)) ? chargeMag : 3.0;
        const dVal = (typeof separation === "number" && !isNaN(separation)) ? separation : 5.0;

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase; letter-spacing:0.5px; color:#00ffd2;">' + "${title}" + '</div>' +
          '<div style="font-size:10px; opacity:0.9; margin-top:3px; font-family: monospace;">' +
            'Charge q = ' + qVal.toFixed(1) + ' C &nbsp;|&nbsp; Distance d = ' + dVal.toFixed(1) + ' m' +
          '</div>' +
          '<div style="font-size:10px; opacity:0.85; margin-top:2px; color:#a1a1aa;">' +
            'Moment p = ' + (qVal * dVal).toFixed(1) + ' C-m &nbsp;|&nbsp; Potential V approx p cos(theta) / r2' +
          '</div>';

        const projV_A = new THREE.Vector3();
        projV_A.copy(posMesh.position).applyMatrix4(dipoleGroup.matrixWorld).project(camera);
        labelA.style.left = (projV_A.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
        labelA.style.top = (-(projV_A.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 25) + "px";

        const projV_B = new THREE.Vector3();
        projV_B.copy(negMesh.position).applyMatrix4(dipoleGroup.matrixWorld).project(camera);
        labelB.style.left = (projV_B.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
        labelB.style.top = (-(projV_B.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 25) + "px";

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          let separationChanged = false;
          if (p.speed !== undefined) speed = Number(p.speed);
          if (p.sizeScale !== undefined) scale = Number(p.sizeScale);
          if (p.chargeMag !== undefined) {
            chargeMag = Number(p.chargeMag);
            posLight.intensity = chargeMag;
            negLight.intensity = chargeMag;
          }
          if (p.separation !== undefined && Number(p.separation) !== separation) {
            separation = Number(p.separation);
            separationChanged = true;
          }
          if (p.wireframe !== undefined) showLines = !!p.wireframe;

          if (separationChanged) {
            rebuildFieldLines();
          }
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelA && labelA.parentNode) labelA.parentNode.removeChild(labelA);
          if (labelB && labelB.parentNode) labelB.parentNode.removeChild(labelB);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 5: PHYSICS MAGNET DIPOLE FIELD LINES
  // ==========================================
  else if (isMagnet) {
    explanation = `### Dipole Magnetism Field Vector Flux
This electrodynamics engine simulates magnetic induction paths and vector flux line fields for **${title}**.

#### Dipole Mathematical Formulation
The vector magnetic induction equation at coordinate vector $\\mathbf{r}$ models classical magnetic parameters:

$$\\mathbf{B}(\\mathbf{r}) = \\frac{\\mu_0}{4\\pi} \\left[ \\frac{3(\\mathbf{m} \\cdot \\hat{\\mathbf{r}})\\hat{\\mathbf{r}} - \\mathbf{m}}{r^3} \\right]$$

Where $\\mathbf{m}$ is the magnetic moment vector and $r$ is the field distance relative to pole coordinates.

#### Flux Contours
Field field loops traverse from North (Crimson Red) to South (Cyan Blue) poles. Particles stream seamlessly along active coordinates tracing continuous paths.`;

    controlsGuide = "Orbit to examine flow directions. Particles stream from the North (Crimson Red) to South (Cyan Blue) magnet faces.";

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#020205");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 8, 16);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      scene.add(new THREE.AmbientLight("#151a30", 1.0));
      const light = new THREE.DirectionalLight("#fff", 1.5); light.position.set(5,10,5); scene.add(light);

      let speed = currentParams.speed || 1.0;
      let scale = currentParams.sizeScale || 1.0;
      let showLines = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      // Physical North/South Magnet Bar
      const barGroup = new THREE.Group();
      scene.add(barGroup);

      const barGeom = new THREE.BoxGeometry(4, 1.2, 1.2);
      const northMat = new THREE.MeshStandardMaterial({ color: "#ef4444", roughness: 0.2 });
      const southMat = new THREE.MeshStandardMaterial({ color: "#06b6d4", roughness: 0.2 });

      const nBody = new THREE.Mesh(barGeom, northMat); nBody.position.x = 2; barGroup.add(nBody);
      const sBody = new THREE.Mesh(barGeom, southMat); sBody.position.x = -2; barGroup.add(sBody);

      // Curved field loop filaments
      const curvesList = [];
      const curvesMeshes = [];
      const loopCount = 10;

      for (let i = 0; i < loopCount; i++) {
        const h = 1.5 + (i * 0.8);
        const w = 3.0 + (i * 1.0);
        const side = i % 2 === 0 ? 1 : -1;
        
        const pathPoints = [
          new THREE.Vector3(2, 0, 0),
          new THREE.Vector3(w * 0.5, h * side, 0),
          new THREE.Vector3(0, (h + 1.2) * side, 0),
          new THREE.Vector3(-w * 0.5, h * side, 0),
          new THREE.Vector3(-2, 0, 0)
        ];

        const curve = new THREE.CatmullRomCurve3(pathPoints);
        curvesList.push(curve);

        const tubeGeo = new THREE.TubeGeometry(curve, 32, 0.05, 8, false);
        const tubeMat = new THREE.MeshBasicMaterial({ color: "#22d3ee", transparent: true, opacity: 0.35 });
        const tube = new THREE.Mesh(tubeGeo, tubeMat);
        scene.add(tube);
        curvesMeshes.push(tube);
      }

      // Tracer Flux Flow particles
      const dotGeo = new THREE.SphereGeometry(0.12, 8, 8);
      const dotMat = new THREE.MeshBasicMaterial({ color: "#0ffff0" });
      const dots = [];

      for (let d = 0; d < 25; d++) {
        const dot = new THREE.Mesh(dotGeo, dotMat);
        scene.add(dot);
        dots.push({
          mesh: dot,
          curveIndex: d % curvesList.length,
          pos: Math.random()
        });
      }

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
      topCard.style.border = "1.5px solid #06b6d4"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelA = document.createElement("div");
      labelA.style.position = "absolute"; labelA.style.zIndex = "10"; labelA.style.pointerEvents = "none";
      labelA.style.background = "rgba(10, 10, 15, 0.85)"; labelA.style.border = "1.5px solid #ef4444"; labelA.style.borderRadius = "5px";
      labelA.style.padding = "2px 6px"; labelA.style.color = "#ffffff"; labelA.style.fontSize = "9px"; labelA.style.transform = "translate(-50%, -50%)";
      labelA.textContent = "North Pole (N)";
      container.appendChild(labelA);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime() * speed;

        barGroup.rotation.y = elapsed * 0.2;
        barGroup.scale.set(scale, scale, scale);

        curvesMeshes.forEach((cm) => {
          cm.visible = showLines;
          cm.rotation.y = barGroup.rotation.y;
          cm.scale.set(scale, scale, scale);
        });

        dots.forEach((d) => {
          d.pos += 0.012 * speed;
          if (d.pos > 1.0) d.pos = 0;
          const pt = curvesList[d.curveIndex].getPointAt(d.pos);
          
          d.mesh.position.copy(pt).applyAxisAngle(new THREE.Vector3(0, 1, 0), barGroup.rotation.y).multiplyScalar(scale);
          d.mesh.visible = showLines;
        });

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Flux field loops model B(r) vector direction</div>';

        const projV = new THREE.Vector3();
        projV.copy(nBody.position).applyMatrix4(barGroup.matrixWorld).project(camera);
        labelA.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
        labelA.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) speed = Number(p.speed);
          if (p.sizeScale !== undefined) scale = Number(p.sizeScale);
          if (p.wireframe !== undefined) showLines = !!p.wireframe;
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelA && labelA.parentNode) labelA.parentNode.removeChild(labelA);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 5.5: FOURIER SERIES WAVE SYNTHESIS
  // ==========================================
  else if (isFourier) {
    explanation = `### Fourier Series Wave Synthesis
This wave formulation mechanics laboratory visualizes the mathematical decomposition and continuous infinite harmonic synthesis of **${title}**.

#### Fourier Expansion & Harmonic Trigonometry
The classic continuous decomposition theorem of Jean-Baptiste Joseph Fourier states that any orthogonal periodic real-valued signal can be formulated as a sum of discrete complex phasor harmonics:

$$f(t) = \\sum_{n=1,3,5,\\dots}^{\\infty} \\frac{4}{\\pi n} \\sin(n \\omega t)$$

#### Harmonic Vector Epicycles
Each term $n$ translates physically to a rotation coordinate with angular velocity $n \\cdot \\omega$ and component amplitude $r_n = \\frac{4}{\\pi n}$:
- **Phasor Vectors**: Modeled as linked circular orbital nodes.
- **Trace Projection**: The cumulative coordinate endpoints trace out the synthesized amplitude curve, projecting high-fidelity sine values onto the scrolling history lane.`;

    controlsGuide = "Orbit to observe the rotating circular epicycles. Modify Simulation Speed to accelerate phasor rotation, and toggle Structure Mode to hide the vector pointers.";

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#030308");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 0, 12);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      scene.add(new THREE.AmbientLight("#1e1e2d", 1.8));
      const pLight = new THREE.PointLight("#38bdf8", 3, 50);
      pLight.position.set(0, 5, 10);
      scene.add(pLight);

      let simSpeed = currentParams.speed || 1.0;
      let ampScale = currentParams.sizeScale || 1.0;
      let showEpicycles = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      // Create a scrolling wave geometry
      const wavePointsCount = 200;
      const wavePositions = new Float32Array(wavePointsCount * 3);
      for (let i = 0; i < wavePointsCount; i++) {
        wavePositions[i * 3] = i * 0.05 + 1.2; // Start wave to the right of the drawing center
        wavePositions[i * 3 + 1] = 0;
        wavePositions[i * 3 + 2] = 0;
      }

      const waveGeo = new THREE.BufferGeometry();
      waveGeo.setAttribute("position", new THREE.BufferAttribute(wavePositions, 3));
      const waveMat = new THREE.LineBasicMaterial({ color: "#00eedd", linewidth: 2.5 });
      const waveLine = new THREE.Line(waveGeo, waveMat);
      scene.add(waveLine);

      // Construct Phasor Epicycle Orbit Circles and Pointer lines (5 harmonics odd terms)
      const circleCount = 5;
      const circles = [];
      const parentGroup = new THREE.Group();
      scene.add(parentGroup);

      for (let i = 0; i < circleCount; i++) {
        const nIdx = i * 2 + 1; // 1, 3, 5, 7, 9
        const radius = (2.6 / nIdx);

        // Circular ring contour
        const rGeo = new THREE.RingGeometry(radius - 0.03, radius + 0.01, 48);
        const rMat = new THREE.MeshBasicMaterial({ color: "#581c87", side: THREE.DoubleSide, transparent: true, opacity: 0.4 });
        const ringMesh = new THREE.Mesh(rGeo, rMat);
        parentGroup.add(ringMesh);

        // Vector line pointer
        const lineGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(radius, 0, 0)]);
        const lineMat = new THREE.LineBasicMaterial({ color: "#f472b6", transparent: true, opacity: 0.8 });
        const lineMesh = new THREE.Line(lineGeo, lineMat);
        parentGroup.add(lineMesh);

        circles.push({
          ring: ringMesh,
          pointer: lineMesh,
          val: nIdx,
          radius: radius
        });
      }

      // Connecting horizontal dashed projector link
      const connGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, 0)]);
      const connMat = new THREE.LineBasicMaterial({ color: "#ffffff", transparent: true, opacity: 0.6 });
      const connLine = new THREE.Line(connGeo, connMat);
      scene.add(connLine);

      // Top detail status annotation
      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
      topCard.style.border = "1.5px solid #06b6d4"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelA = document.createElement("div");
      labelA.style.position = "absolute"; labelA.style.zIndex = "10"; labelA.style.pointerEvents = "none";
      labelA.style.background = "rgba(10, 10, 15, 0.9)"; labelA.style.border = "1.5px solid #00ffcc"; labelA.style.borderRadius = "5px";
      labelA.style.padding = "2px 6px"; labelA.style.color = "#ffffff"; labelA.style.fontSize = "9px"; labelA.style.transform = "translate(-50%, -50%)";
      labelA.textContent = "Sum f(t)";
      container.appendChild(labelA);

      const clock = new THREE.Clock();
      let animId;
      const history = [];

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime() * 1.5 * simSpeed;

        let cx = -3.2; // Offset epicycle sum coordinate source leftwards
        let cy = 0;

        for (let i = 0; i < circleCount; i++) {
          const c = circles[i];
          c.ring.position.set(cx, cy, 0);
          c.ring.visible = showEpicycles;

          const angle = c.val * elapsed;
          const nextCx = cx + Math.cos(angle) * c.radius * ampScale;
          const nextCy = cy + Math.sin(angle) * c.radius * ampScale;

          const posAttr = c.pointer.geometry.attributes.position;
          posAttr.setXYZ(0, cx, cy, 0);
          posAttr.setXYZ(1, nextCx, nextCy, 0);
          posAttr.needsUpdate = true;
          c.pointer.visible = showEpicycles;

          cx = nextCx;
          cy = nextCy;
        }

        // Push calculated sum height values down wave history queue
        history.unshift(cy);
        if (history.length > wavePointsCount) history.pop();

        // Feed positions into Wavefront Scrolling line
        const wavePosAttr = waveLine.geometry.attributes.position;
        for (let idx = 0; idx < wavePointsCount; idx++) {
          const valY = idx < history.length ? history[idx] : 0;
          wavePosAttr.setY(idx, valY);
        }
        wavePosAttr.needsUpdate = true;

        // Anchor dynamic dashed projection guide from rotating coordinate tip to scrolling curve start
        const connPosAttr = connLine.geometry.attributes.position;
        connPosAttr.setXYZ(0, cx, cy, 0);
        connPosAttr.setXYZ(1, 1.2, cy, 0);
        connPosAttr.needsUpdate = true;
        connLine.visible = showEpicycles;

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Signal Mechanics: odd harmonic Fourier epicycles (N=5 terms)</div>';

        const projV = new THREE.Vector3(cx, cy, 0);
        projV.project(camera);
        labelA.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
        labelA.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) simSpeed = Number(p.speed);
          if (p.sizeScale !== undefined) ampScale = Number(p.sizeScale);
          if (p.wireframe !== undefined) showEpicycles = !!p.wireframe;
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelA && labelA.parentNode) labelA.parentNode.removeChild(labelA);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 6: PHYSICS WAVE SUPERPOSITION
  // ==========================================
  else if (isWave) {
    explanation = `### Double Slit Wave Optics Superposition
This physical wave engine models coherent wavefront interference grids and intensity patterns for **${title}**.

#### Electro-Optical Superposition Principle
The cumulative field amplitude $\\Psi$ at any screen coordinate is the algebraic sum of emanating wavefronts from the two slits:

$$\\Psi(\\mathbf{r}, t) = A_1 \\cos(k r_1 - \\omega t) + A_2 \\cos(k r_2 - \\omega t)$$

#### Fringe Diffraction Contours
The resulting path phase difference generates spatial intensity variations:
- **Constructive (Bright fringes)**: $\\Delta \\phi = 2m\\pi$, yielding double amplitude
- **Destructive (Dark lines)**: $\\Delta \\phi = (2m+1)\\pi$, resulting in complete vector cancellation`;

    controlsGuide = "Orbit to examine wave diffraction peaks. The animated ripple plane demonstrates peaks (white/teal) and troughs (black).";

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#050510");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 14, 20);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      scene.add(new THREE.AmbientLight("#2b2b4a", 1.5));
      const dirL = new THREE.DirectionalLight("#00ffcc", 2.0); dirL.position.set(0, 20, 10); scene.add(dirL);

      let simSpeed = currentParams.speed || 1.0;
      let gridScale = currentParams.sizeScale || 1.0;
      let waveMode = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      // Ripple surface geom
      const planeGeo = new THREE.PlaneGeometry(24, 24, 60, 60);
      const planeMat = new THREE.MeshStandardMaterial({
        color: "#00eedd",
        wireframe: true,
        roughness: 0.1,
        transparent: true,
        opacity: 0.7,
        side: THREE.DoubleSide
      });
      const mesh = new THREE.Mesh(planeGeo, planeMat);
      mesh.rotation.x = -Math.PI / 2;
      mesh.position.y = -1;
      scene.add(mesh);

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
      topCard.style.border = "1.5px solid #00ffcc"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelA = document.createElement("div");
      labelA.style.position = "absolute"; labelA.style.zIndex = "10"; labelA.style.pointerEvents = "none";
      labelA.style.background = "rgba(10, 10, 15, 0.9)"; labelA.style.border = "1.5px solid #00ffcc"; labelA.style.borderRadius = "5px";
      labelA.style.padding = "2px 6px"; labelA.style.color = "#ffffff"; labelA.style.fontSize = "9px"; labelA.style.transform = "translate(-50%, -50%)";
      labelA.textContent = "Coherent Wave Node";
      container.appendChild(labelA);

      const clock = new THREE.Clock();
      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const elapsed = clock.getElapsedTime() * simSpeed;

        mesh.scale.set(gridScale, gridScale, gridScale);
        planeMat.wireframe = waveMode;

        // Animate wave vertices mathematically (Dual coherent origins mimicking slit diffraction)
        const posAttr = planeGeo.attributes.position;
        const slitDist = 3.5;
        const frequency = 2.5;

        for (let i = 0; i < posAttr.count; i++) {
          const x = posAttr.getX(i);
          const y = posAttr.getY(i);
          
          // Distance from Source A & Source B
          const d1 = Math.sqrt((x - slitDist) * (x - slitDist) + (y + 10) * (y + 10));
          const d2 = Math.sqrt((x + slitDist) * (x + slitDist) + (y + 10) * (y + 10));
          
          const amp1 = Math.sin(d1 - elapsed * frequency) / (d1 * 0.15 + 1);
          const amp2 = Math.sin(d2 - elapsed * frequency) / (d2 * 0.15 + 1);
          
          posAttr.setZ(i, (amp1 + amp2) * 1.1);
        }
        planeGeo.computeVertexNormals();
        posAttr.needsUpdate = true;

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Dual coherent nodes overlay active</div>';

        const projV = new THREE.Vector3();
        projV.set(4, 0, 4).project(camera);
        labelA.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
        labelA.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) simSpeed = Number(p.speed);
          if (p.sizeScale !== undefined) gridScale = Number(p.sizeScale);
          if (p.wireframe !== undefined) waveMode = !!p.wireframe;
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelA && labelA.parentNode) labelA.parentNode.removeChild(labelA);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 7: PHYSICS DOUBLE PENDULUM / CHAOS
  // ==========================================
  else if (isPendulum) {
    explanation = `### Coupled Double Pendulum Chaotic Oscillations
This kinematics simulator integrates chaotic motion coordinates for **${title}**.

#### Coupled Differential Integrations
Coupled equations model the state vectors of double swinging rods. Let $\\theta_1$ and $\\theta_2$ dictate the active angles:

$$\\tau_1 = m_1 l_1^2 \\ddot{\\theta}_1 + m_2 l_1^2 \\ddot{\\theta}_1 + m_2 l_1 l_2 \\ddot{\\theta}_2 \\cos(\\theta_1 - \\theta_2)$$

The dynamic state space is highly sensitive to initial coordinates, yielding classical chaotic behavior:

$$\\lambda = \\lim_{t \\rightarrow \\infty} \\frac{1}{t} \\ln \\frac{|\\Delta \\mathbf{x}(t)|}{|\\Delta \\mathbf{x}_0|}$$

Where $\\lambda > 0$ defines the positive Lyapunov exponent characteristic of chaos.`;

    controlsGuide = "Orbit to examine path records. The trail registers historical positions of Bob 2, mapping phase-space chaos.";

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#05050e");

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 0, 16);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      scene.add(new THREE.AmbientLight("#1c1917", 1.5));
      const light = new THREE.PointLight("#fbbf24", 5, 50); scene.add(light);

      let simSpeed = currentParams.speed || 1.0;
      let scale = currentParams.sizeScale || 1.0;
      let isTrail = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

      // Pendulum mechanics state
      let th1 = Math.PI / 2;
      let th2 = Math.PI / 2 + 0.3;
      let w1 = 0;
      let w2 = 0;
      const l1 = 3.2;
      const l2 = 2.8;
      const m1 = 1.0;
      const m2 = 1.0;
      const g = 9.81;

      // Visual meshes
      const rodGroup = new THREE.Group();
      scene.add(rodGroup);

      const b1Mesh = new THREE.Mesh(new THREE.SphereGeometry(0.5, 16, 16), new THREE.MeshStandardMaterial({ color: "#fbbf24", roughness: 0.2 }));
      const b2Mesh = new THREE.Mesh(new THREE.SphereGeometry(0.5, 16, 16), new THREE.MeshStandardMaterial({ color: "#f59e0b", roughness: 0.2 }));
      rodGroup.add(b1Mesh);
      rodGroup.add(b2Mesh);

      // Rod cylinder paths
      const rod1 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1, 8), new THREE.MeshStandardMaterial({ color: "#e7e5e4" }));
      const rod2 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1, 8), new THREE.MeshStandardMaterial({ color: "#a8a29e" }));
      rodGroup.add(rod1);
      rodGroup.add(rod2);

      // Dynamic trail line
      const maxPoints = 120;
      const trailPositions = new Float32Array(maxPoints * 3);
      const trailGeo = new THREE.BufferGeometry();
      trailGeo.setAttribute("position", new THREE.BufferAttribute(trailPositions, 3));
      const trailMat = new THREE.LineBasicMaterial({ color: "#ea580c" });
      const trailLine = new THREE.Line(trailGeo, trailMat);
      scene.add(trailLine);

      const trailArr = [];

      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
      topCard.style.border = "1.5px solid #d97706"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
      topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      container.appendChild(topCard);

      const labelNode = document.createElement("div");
      labelNode.style.position = "absolute"; labelNode.style.zIndex = "10"; labelNode.style.pointerEvents = "none";
      labelNode.style.background = "rgba(10, 10, 15, 0.85)"; labelNode.style.border = "1.5px solid #fbbf24"; labelNode.style.borderRadius = "5px";
      labelNode.style.padding = "2px 6px"; labelNode.style.color = "#ffffff"; labelNode.style.fontSize = "9px"; labelNode.style.transform = "translate(-50%, -50%)";
      labelNode.textContent = "Coupled Bob 1";
      container.appendChild(labelNode);

      let animId;

      function draw() {
        animId = requestAnimationFrame(draw);
        const dt = 0.016 * simSpeed;

        // Perform double pendulum equations equations of motion using high-fidelity sub-stepping to prevent numeric blow-ups at high speeds
        const substeps = 12;
        const subDt = dt / substeps;
        for (let s = 0; s < substeps; s++) {
          const mu = 1 + m1 / m2;
          const dTh = th1 - th2;

          const num1 = g * (Math.sin(th2) * Math.cos(dTh) - mu * Math.sin(th1)) - (l2 * w2 * w2 + l1 * w1 * w1 * Math.cos(dTh)) * Math.sin(dTh);
          const den1 = l1 * (mu - Math.cos(dTh) * Math.cos(dTh));
          const alpha1 = num1 / den1;

          const num2 = g * mu * (Math.sin(th1) * Math.cos(dTh) - Math.sin(th2)) + (mu * l1 * w1 * w1 + l2 * w2 * w2 * Math.cos(dTh)) * Math.sin(dTh);
          const den2 = l2 * (mu - Math.cos(dTh) * Math.cos(dTh));
          const alpha2 = num2 / den2;

          w1 += alpha1 * subDt;
          w2 += alpha2 * subDt;

          // Clamp angular velocities gently to prevent mathematical overflow swings
          w1 = Math.max(-45, Math.min(45, w1));
          w2 = Math.max(-45, Math.min(45, w2));

          th1 += w1 * subDt;
          th2 += w2 * subDt;
        }

        // Cartesian state solutions
        const x1 = l1 * Math.sin(th1) * scale;
        const y1 = -l1 * Math.cos(th1) * scale;
        const x2 = x1 + l2 * Math.sin(th2) * scale;
        const y2 = y1 - l2 * Math.cos(th2) * scale;

        b1Mesh.position.set(x1, y1, 0);
        b2Mesh.position.set(x2, y2, 0);

        // Adjust cylinder joints
        rod1.position.set(x1 * 0.5, y1 * 0.5, 0);
        rod1.scale.set(1, l1 * scale, 1);
        rod1.rotation.z = th1;

        rod2.position.set((x1 + x2) * 0.5, (y1 + y2) * 0.5, 0);
        rod2.scale.set(1, l2 * scale, 1);
        rod2.rotation.z = th2;

        // Log trails
        trailArr.push(new THREE.Vector3(x2, y2, 0));
        if (trailArr.length > maxPoints) trailArr.shift();

        trailLine.visible = isTrail;
        const pos = trailGeo.attributes.position;
        for (let i = 0; i < maxPoints; i++) {
          if (trailArr[i]) {
            pos.setXYZ(i, trailArr[i].x, trailArr[i].y, trailArr[i].z);
          } else {
            pos.setXYZ(i, x2, y2, 0);
          }
        }
        pos.needsUpdate = true;

        topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Lyapunov Exponent > 0 (Chaotic Mode)</div>';

        const projV = new THREE.Vector3();
        projV.copy(b1Mesh.position).project(camera);
        labelNode.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
        labelNode.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.speed !== undefined) simSpeed = Number(p.speed);
          if (p.sizeScale !== undefined) scale = Number(p.sizeScale);
          if (p.wireframe !== undefined) isTrail = !!p.wireframe;
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          if (labelNode && labelNode.parentNode) labelNode.parentNode.removeChild(labelNode);
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 11: MARITIME NAVIGATION & STABILITY
  // ==========================================
  else if (isMaritime) {
    explanation = `### Transverse Vessel Stability & Metacentric Physics
This advanced simulation visualizes ship hydrostatics, buoyancy, and transverse stability metrics, designed specifically for **Merchant Navy and Marine Engineering** students studying **${title}**.

#### Hydrostatic Equilibrium & Archimedes' Principle
A floating vessel operates under hydrostatic equilibrium, where gravity forces acting downwards are perfectly balanced by buoyancy forces acting upwards:

$$\\Delta = \\rho_{water} \\cdot \\nabla$$

Where:
- $\\Delta$ is ship displacement (mass).
- $\\rho_{water}$ is seawater density ($1.025 \\text{ tonnes/m}^3$).
- $\\nabla$ is submerged underwater volume.

#### Transverse Stability & Metacentric Height ($GM$)
When external waves or wind heel the ship by an angle $\\theta$, the Center of Buoyancy shifts from $B$ to $B_1$. The buoyant force acts vertically upwards through $B_1$, intersecting the centerline at the **Metacentre ($M$)**.

The stability margin is determined by the **Metacentric Height ($GM$)**:

$$GM = KB + BM - KG$$

Where:
- $KB$ is Center of Buoyancy height above the keel ($K$).
- $BM$ is the Metacentric Radius ($I_y / \\nabla$, governed by the transverse moment of inertia of the waterplane).
- $KG$ is the Center of Gravity height above the keel.

#### Stability Criteria
- **Stable ($GM > 0$)**: The righting lever $GZ = GM \\sin\\theta$ acts as a restoring torque, pulling the ship upright.
- **Unstable ($GM < 0$)**: The vessel capsizes or lists heavily because gravity and buoyancy form a capsizing moment.`;

    controlsGuide = "Orbit to inspect the hull, container stack, and forces. Adjust Ballast/Mass, Beam Width, or Sea Roughness to test buoyancy and capsize scenarios.";

    interactiveParameters = [
      { name: "ballast", label: "Cargo Load & Ballast (Mass)", type: "slider", min: 0.2, max: 2.0, step: 0.1, default: 1.0 },
      { name: "beamWidth", label: "Hull Beam Width (M)", type: "slider", min: 0.8, max: 2.5, step: 0.1, default: 1.6 },
      { name: "seaRoughness", label: "Sea Roughness (Waves)", type: "slider", min: 0.0, max: 2.5, step: 0.1, default: 0.8 }
    ];

    fallbackCode = `
      const width = container.clientWidth;
      const height = container.clientHeight;
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#050811"); // Deep nautical night

      const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
      camera.position.set(0, 4, 15);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;

      // Lighting representing glowing high-visibility markers
      const ambLight = new THREE.AmbientLight("#112233", 1.5);
      scene.add(ambLight);

      const light1 = new THREE.PointLight("#00ffff", 5, 50);
      light1.position.set(10, 10, 10);
      scene.add(light1);

      const light2 = new THREE.PointLight("#ffff00", 3, 50);
      light2.position.set(-10, 5, -10);
      scene.add(light2);

      let ballast = currentParams.ballast !== undefined ? Number(currentParams.ballast) : 1.0;
      let beamWidth = currentParams.beamWidth !== undefined ? Number(currentParams.beamWidth) : 1.6;
      let seaRoughness = currentParams.seaRoughness !== undefined ? Number(currentParams.seaRoughness) : 0.8;

      // Group containing the entire vessel
      const shipGroup = new THREE.Group();
      scene.add(shipGroup);

      // Create the Ship Hull
      const hullGeo = new THREE.BoxGeometry(beamWidth * 2.5, 1.2, 5.0);
      const hullMat = new THREE.MeshStandardMaterial({
        color: "#1e293b",
        roughness: 0.4,
        metalness: 0.8,
        wireframe: false
      });
      const hull = new THREE.Mesh(hullGeo, hullMat);
      hull.position.y = 0;
      shipGroup.add(hull);

      // Keel visual marker (bottom of hull)
      const keelGeo = new THREE.BoxGeometry(0.1, 0.1, 5.2);
      const keelMat = new THREE.MeshBasicMaterial({ color: "#ef4444" });
      const keel = new THREE.Mesh(keelGeo, keelMat);
      keel.position.y = -0.6;
      shipGroup.add(keel);

      // Deck Cabin / Bridge superstructure
      const cabinGeo = new THREE.BoxGeometry(beamWidth * 1.8, 1.0, 1.5);
      const cabinMat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.5 });
      const cabin = new THREE.Mesh(cabinGeo, cabinMat);
      cabin.position.set(0, 1.1, -1.5);
      shipGroup.add(cabin);

      // Cargo containers stacked on deck (represents cargo mass distribution)
      const cargoGroup = new THREE.Group();
      shipGroup.add(cargoGroup);

      const colors = ["#ef4444", "#3b82f6", "#10b981", "#f59e0b"];
      const containersList = [];
      for (let x = -1; x <= 1; x++) {
        for (let z = 0; z <= 2; z++) {
          const blockGeo = new THREE.BoxGeometry(0.5, 0.5, 1.0);
          const blockMat = new THREE.MeshStandardMaterial({
            color: colors[(x + z + 5) % colors.length],
            roughness: 0.6
          });
          const block = new THREE.Mesh(blockGeo, blockMat);
          block.position.set(x * 0.6, 0.85, z * 1.0 + 0.5);
          cargoGroup.add(block);
          containersList.push(block);
        }
      }

      // Sea Surface Wave Mesh
      const seaGeo = new THREE.PlaneGeometry(24, 24, 30, 30);
      const seaMat = new THREE.MeshStandardMaterial({
        color: "#0c4a6e",
        emissive: "#0369a1",
        roughness: 0.3,
        metalness: 0.2,
        transparent: true,
        opacity: 0.75,
        wireframe: true
      });
      const sea = new THREE.Mesh(seaGeo, seaMat);
      sea.rotation.x = -Math.PI / 2;
      sea.position.y = -0.4;
      scene.add(sea);

      // Visual helper points for Metacentre (M), Center of Gravity (G), Center of Buoyancy (B)
      const pointGeo = new THREE.SphereGeometry(0.12, 16, 16);
      
      const mPoint = new THREE.Mesh(pointGeo, new THREE.MeshBasicMaterial({ color: "#facc15" })); // Metacentre: Yellow
      scene.add(mPoint);

      const gPoint = new THREE.Mesh(pointGeo, new THREE.MeshBasicMaterial({ color: "#ef4444" })); // Center of Gravity: Red
      scene.add(gPoint);

      const bPoint = new THREE.Mesh(pointGeo, new THREE.MeshBasicMaterial({ color: "#06b6d4" })); // Center of Buoyancy: Cyan
      scene.add(bPoint);

      // Dynamic arrow helper lines
      const arrowG = new THREE.ArrowHelper(
        new THREE.Vector3(0, -1, 0),
        new THREE.Vector3(0, 0, 0),
        1.5,
        "#ef4444",
        0.3,
        0.15
      );
      scene.add(arrowG);

      const arrowB = new THREE.ArrowHelper(
        new THREE.Vector3(0, 1, 0),
        new THREE.Vector3(0, 0, 0),
        1.5,
        "#06b6d4",
        0.3,
        0.15
      );
      scene.add(arrowB);

      // Add elegant floating overlay HUD
      const topCard = document.createElement("div");
      topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
      topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 15, 30, 0.9)";
      topCard.style.border = "1.5px solid #06b6d4"; topCard.style.borderRadius = "10px"; topCard.style.padding = "8px 16px";
      topCard.style.fontFamily = "monospace"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
      topCard.style.boxShadow = "0 0 15px rgba(6, 182, 212, 0.4)";
      container.appendChild(topCard);

      let animId;
      let clock = new THREE.Clock();

      function draw() {
        animId = requestAnimationFrame(draw);
        const time = clock.getElapsedTime();

        // 1. Calculate wave height under the ship
        // Floating motion: heave, pitch and roll based on seaRoughness
        const heave = Math.sin(time * 1.5) * 0.1 * seaRoughness;
        const waveAngle = Math.sin(time * 1.2) * 0.15 * seaRoughness; // Rolled by waves

        // 2. Draft / vertical position is affected by ballast
        const draftOffset = -0.2 * ballast; // More ballast sinks the hull deeper
        shipGroup.position.y = draftOffset + heave;

        // 3. Metacentric stability calculations
        // Transverse stability BM increases as beamWidth cubed / volume (or simply proportional to beamWidth^2)
        const KB = 0.3 * (1 + ballast); // center of buoyancy rises slightly with more load
        const BM = (1.2 * beamWidth * beamWidth) / (1.0 + ballast); // metacentric radius increases with beam, decreases with draft/displacement
        const KG = 0.5 * (1 + 0.3 * ballast); // center of gravity height. Heavy cargo lifts KG up

        const GM = KB + BM - KG; // Metacentric Height

        // 4. Ship behavior based on GM (Transverse Restoring Lever)
        // If GM > 0, the ship returns upright with a restoration frequency proportional to GM
        // If GM <= 0, the ship loses stability and will loll or capsize!
        let roll;
        let stabilityState = "STABLE";
        let stateColor = "#10b981";

        if (GM > 0) {
          // Stable restoration + wave influence
          const restoringFrequency = Math.sqrt(GM * 9.81 / (beamWidth * 0.8));
          roll = waveAngle + Math.sin(time * restoringFrequency) * 0.05;
          shipGroup.rotation.z = roll;
          shipGroup.rotation.x = Math.sin(time * 0.8) * 0.03 * seaRoughness; // gentle pitch
        } else {
          // Capsize scenario! GM is negative or zero. Ship rolls to heavy list (angle of loll) or capsizes
          const listAngle = GM < -0.2 ? -Math.PI / 3.5 : -Math.PI / 6;
          roll = listAngle + Math.sin(time * 0.5) * 0.02;
          shipGroup.rotation.z = roll;
          shipGroup.rotation.x = 0.05;
          stabilityState = GM < -0.25 ? "CAPSIZED! (Unstable GM)" : "HEAVY LIST (Negative GM)";
          stateColor = "#ef4444";
        }

        // 5. Update wave mesh animation
        const posAttr = seaGeo.attributes.position;
        for (let i = 0; i < posAttr.count; i++) {
          const x = posAttr.getX(i);
          const y = posAttr.getY(i);
          const z = Math.sin(x * 0.3 + time * 1.5) * 0.15 * seaRoughness + Math.cos(y * 0.3 + time * 1.2) * 0.15 * seaRoughness;
          posAttr.setZ(i, z);
        }
        posAttr.needsUpdate = true;

        // 6. Update position of hydrostatic points: G, B, M
        // Position them relative to the world coordinates to show their spatial orientation
        const shipY = shipGroup.position.y;
        
        // Center of Gravity (G)
        const worldG = new THREE.Vector3(0, KG - 0.6, 0).applyMatrix4(shipGroup.matrixWorld);
        gPoint.position.copy(worldG);

        // Center of Buoyancy (B)
        const worldB = new THREE.Vector3(0, KB - 0.6, 0).applyMatrix4(shipGroup.matrixWorld);
        bPoint.position.copy(worldB);

        // Metacentre (M)
        const worldM = new THREE.Vector3(0, (KB + BM) - 0.6, 0).applyMatrix4(shipGroup.matrixWorld);
        mPoint.position.copy(worldM);

        // Update vector arrows
        arrowG.position.copy(worldG);
        arrowB.position.copy(worldB);

        // Arrow G points straight down (gravity)
        arrowG.setDirection(new THREE.Vector3(0, -1, 0));
        // Arrow B points perpendicular to shifted waterline (buoyancy force acts straight up)
        arrowB.setDirection(new THREE.Vector3(0, 1, 0));

        // 7. Render dynamic HUD stats
        const rollDeg = Math.abs(roll * 180 / Math.PI).toFixed(1);
        const currentDraft = (0.6 - shipY).toFixed(2);
        
        topCard.innerHTML = '<div style="font-weight:bold; font-size:12px; margin-bottom:4px; text-align:center; color:#38bdf8;">' +
             '⛴️ MERCHANT NAVY SHIP HYDROSTATICS' +
          '</div>' +
          '<div style="display:grid; grid-template-columns:100px 1fr; gap:2px;">' +
            '<span>Stability:</span><strong style="color:' + stateColor + ';">' + stabilityState + '</strong>' +
            '<span>GM Height:</span><strong>' + GM.toFixed(2) + ' m</strong>' +
            '<span>Roll Angle:</span><strong>' + rollDeg + '°</strong>' +
            '<span>Vessel Draft:</span><strong>' + currentDraft + ' m</strong>' +
            '<span>Restoring Lever (GZ):</span><strong>' + (GM * Math.sin(Math.abs(roll))).toFixed(3) + ' m</strong>' +
          '</div>' +
          '<div style="font-size:9px; color:#94a3b8; border-top:1px solid #1e293b; margin-top:6px; padding-top:4px;">' +
            '<span style="color:#ef4444;">● G (Gravity)</span> | ' +
            '<span style="color:#06b6d4;">● B (Buoyancy)</span> | ' +
            '<span style="color:#facc15;">● M (Metacentre)</span>' +
          '</div>';

        controls.update();
        renderer.render(scene, camera);
      }
      draw();

      return {
        updateParams: (p) => {
          if (p.ballast !== undefined) {
            ballast = Number(p.ballast);
          }
          if (p.beamWidth !== undefined) {
            beamWidth = Number(p.beamWidth);
            hull.scale.x = beamWidth / 1.6;
            cabin.scale.x = beamWidth / 1.6;
            cargoGroup.scale.x = beamWidth / 1.6;
          }
          if (p.seaRoughness !== undefined) {
            seaRoughness = Number(p.seaRoughness);
          }
        },
        destroy: () => {
          cancelAnimationFrame(animId);
          controls.dispose();
          renderer.dispose();
          if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
          if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
          bPoint.geometry.dispose(); bPoint.material.dispose();
          gPoint.geometry.dispose(); gPoint.material.dispose();
          mPoint.geometry.dispose(); mPoint.material.dispose();
          arrowG.dispose();
          arrowB.dispose();
          scene.traverse((obj) => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
              else obj.material.dispose();
            }
          });
        }
      };
    `;
  }
  // ==========================================
  // BRANCH 8: SMART SEMANTIC PARADIGM ROUTING
  // ==========================================
  else {
    if (classification === "CONST_ORGANIC") {
      explanation = `### Biological Volumetric Cell & Organic Form
This organic viewport visualizes a three-dimensional biological structure representing **${title}**.

#### Organic Geometries & Viscoelastic Dynamics
Biological systems are characterized by soft, fluid viscoelastic boundaries rather than rigid angles. Centered in coordinate space, this volumetric model simulates active cytoplasm-lipid interactions governed by the Kelvin-Voigt viscoelastic tension model:

$$\\sigma(t) = E \\cdot \\varepsilon(t) + \\eta \\cdot \\frac{d\\varepsilon}{dt}$$

Where $E$ represents the elastic modulus and $\\eta$ represents dynamic internal viscosity.

#### Cellular Cohesion Mechanisms
- **Flesh & Tissue Membranes**: Formulated from soft, high-roughness elements mimicking eukaryotic cellular bodies.
- **Microtubule Scaffolding**: Clustered organic bodies arranged in dynamic coordination, actively pulsing with metabolic energy.
- **Zero Coordinates Grid**: Ground alignment, coordinate axes, and artificial measurement wireframes are completely hidden to maintain a sterile, clinical simulation environment in accordance with organic laws.`;

      controlsGuide = "Orbit to inspect tissue structures. Slide 'Visual Scale' to contract or expand the cytoplasm clusters.";

      fallbackCode = `
        const width = container.clientWidth;
        const height = container.clientHeight;
        const scene = new THREE.Scene();
        scene.background = new THREE.Color("#0c0607"); // Deep fleshy darkness

        const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
        camera.position.set(0, 0, 10);

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(width, height);
        container.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;

        // No grids or coordinate helper overlays per requirements
        scene.add(new THREE.AmbientLight("#451c20", 2.2));
        
        const light1 = new THREE.PointLight("#ff5577", 4.5, 30);
        light1.position.set(5, 5, 5);
        scene.add(light1);
        
        const light2 = new THREE.PointLight("#ff7733", 3, 30);
        light2.position.set(-5, -5, 5);
        scene.add(light2);

        let speed = currentParams.speed || 1.0;
        let scale = currentParams.sizeScale || 1.0;

        const organicGroup = new THREE.Group();
        scene.add(organicGroup);

        // Core plus sliding satellites
        const spheres = [];
        const colors = ["#de6b48", "#e76f51", "#ff8866", "#e76f51", "#ca5c3b"];
        for (let i = 0; i < 6; i++) {
          const radius = i === 0 ? 1.7 : 0.5 + Math.random() * 0.5;
          const geom = new THREE.SphereGeometry(radius, 32, 32);
          const mat = new THREE.MeshStandardMaterial({
            color: colors[i % colors.length],
            roughness: 0.95, // strict high roughness per requirements
            metalness: 0.05,
            clearcoat: 0.1
          });
          const mesh = new THREE.Mesh(geom, mat);
          
          const offset = i === 0 ? new THREE.Vector3(0,0,0) : new THREE.Vector3(
            (Math.random() - 0.5) * 1.6,
            (Math.random() - 0.5) * 1.6,
            (Math.random() - 0.5) * 1.6
          );
          mesh.position.copy(offset);
          organicGroup.add(mesh);
          
          spheres.push({ mesh, offset, seed: Math.random() * 200 });
        }

        const topCard = document.createElement("div");
        topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
        topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(15, 10, 10, 0.9)";
        topCard.style.border = "1.5px solid #ff5577"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
        topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
        container.appendChild(topCard);

        const labelNode = document.createElement("div");
        labelNode.style.position = "absolute"; labelNode.style.zIndex = "10"; labelNode.style.pointerEvents = "none";
        labelNode.style.background = "rgba(10, 6, 6, 0.9)"; labelNode.style.border = "1.5px solid #ff5577"; labelNode.style.borderRadius = "5px";
        labelNode.style.padding = "2px 6px"; labelNode.style.color = "#ffffff"; labelNode.style.fontSize = "9px"; labelNode.style.transform = "translate(-50%, -50%)";
        labelNode.textContent = "Volumetric Cytoplasm";
        container.appendChild(labelNode);

        const clock = new THREE.Clock();
        let animId;

        function draw() {
          animId = requestAnimationFrame(draw);
          const elapsed = clock.getElapsedTime() * speed;

          organicGroup.scale.set(scale, scale, scale);
          organicGroup.rotation.y = elapsed * 0.12;
          organicGroup.rotation.x = elapsed * 0.05;

          spheres.forEach((s, idx) => {
            if (idx > 0) {
              const pulse = 1.0 + Math.sin(elapsed * 1.8 + s.seed) * 0.18;
              s.mesh.position.set(s.offset.x * pulse, s.offset.y * pulse, s.offset.z * pulse);
            } else {
              const pulse = 1.0 + Math.sin(elapsed * 1.2) * 0.05;
              s.mesh.scale.set(pulse, pulse, pulse);
            }
          });

          topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Cellular Paradigm: Grouped Organic Volumetric Tissue</div>';

          const projV = new THREE.Vector3();
          projV.copy(spheres[0].mesh.position).applyMatrix4(organicGroup.matrixWorld).project(camera);
          labelNode.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
          labelNode.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";

          controls.update();
          renderer.render(scene, camera);
        }
        draw();

        return {
          updateParams: (p) => {
            if (p.speed !== undefined) speed = Number(p.speed);
            if (p.sizeScale !== undefined) scale = Number(p.sizeScale);
          },
          destroy: () => {
            cancelAnimationFrame(animId);
            controls.dispose();
            renderer.dispose();
            if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
            if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
            if (labelNode && labelNode.parentNode) labelNode.parentNode.removeChild(labelNode);
            scene.traverse((obj) => {
              if (obj.geometry) obj.geometry.dispose();
              if (obj.material) {
                if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
                else obj.material.dispose();
              }
            });
          }
        };
      `;
    }
    else if (classification === "CONST_PARTICLE_CLOUD") {
      explanation = `### Cosmological Cluster Particle Cloud
This numerical visualization organizes multi-node particle clusters representing **${title}**.

#### Chaos Fields and Orbit Trajectories
The cloud structure computes physical system interactions. Let each point particle $\\mathbf{p}_i$ be configured in coordinates space and dynamically interact with a central vortex gravity source:

$$\\mathbf{a}_i = -G \\frac{M}{r_i^2} \\hat{\\mathbf{r}}_i$$

Where $G$ represents systemic gravity, $M$ is the center mass, and $r_i$ denotes target system radii.

#### Vertex Cloud Geometries
- **Additive Blending Point Materials**: Point clusters mapped dynamically utilizing lightweight vertex arrays.
- **Dynamic Orbital Whirlpool**: Motion is animated seamlessly based on local coordinates orbital vectors.`;

      controlsGuide = "Orbit / drag to view coordinate clustering. Slide speed to accelerate orbit vortex velocity.";

      fallbackCode = `
        const width = container.clientWidth;
        const height = container.clientHeight;
        const scene = new THREE.Scene();
        scene.background = new THREE.Color("#030308");

        const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
        camera.position.set(0, 5, 12);

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(width, height);
        container.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;

        scene.add(new THREE.AmbientLight("#111122", 1.5));
        const light = new THREE.PointLight("#38bdf8", 4, 30);
        light.position.set(0, 3, 5);
        scene.add(light);

        let speed = currentParams.speed || 1.0;
        let scale = currentParams.sizeScale || 1.0;

        const particleCount = 2000;
        const positions = new Float32Array(particleCount * 3);
        const colors = new Float32Array(particleCount * 3);
        const pData = [];
        const colPalette = [new THREE.Color("#00ffcc"), new THREE.Color("#d100ec"), new THREE.Color("#38bdf8")];

        for (let i = 0; i < particleCount; i++) {
          const radius = 1.0 + Math.random() * 4.0;
          const angle = Math.random() * Math.PI * 2;
          const yOffset = (Math.random() - 0.5) * 1.5;
          const x = Math.cos(angle) * radius;
          const z = Math.sin(angle) * radius;
          
          positions[i * 3] = x;
          positions[i * 3 + 1] = yOffset;
          positions[i * 3 + 2] = z;

          const c = colPalette[Math.floor(Math.random() * colPalette.length)];
          colors[i * 3] = c.r;
          colors[i * 3 + 1] = c.g;
          colors[i * 3 + 2] = c.b;

          pData.push({ radius, angle, yOffset, speed: 0.5 + Math.random() * 1.5 });
        }

        const pCanvas = document.createElement("canvas");
        pCanvas.width = 16; pCanvas.height = 16;
        const pCtx = pCanvas.getContext("2d");
        const pGrad = pCtx.createRadialGradient(8, 8, 0, 8, 8, 8);
        pGrad.addColorStop(0, "rgba(255, 255, 255, 1)");
        pGrad.addColorStop(1, "rgba(255, 255, 255, 0)");
        pCtx.fillStyle = pGrad; pCtx.fillRect(0, 0, 16, 16);
        const pointTex = new THREE.CanvasTexture(pCanvas);

        const pGeo = new THREE.BufferGeometry();
        pGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
        pGeo.setAttribute("color", new THREE.BufferAttribute(colors, 3));

        const pMat = new THREE.PointsMaterial({
          size: 0.15,
          map: pointTex,
          vertexColors: true,
          transparent: true,
          opacity: 0.85,
          blending: THREE.AdditiveBlending,
          depthWrite: false
        });

        const pointCloud = new THREE.Points(pGeo, pMat);
        scene.add(pointCloud);

        const topCard = document.createElement("div");
        topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
        topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
        topCard.style.border = "1.5px solid #38bdf8"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
        topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
        container.appendChild(topCard);

        const labelNode = document.createElement("div");
        labelNode.style.position = "absolute"; labelNode.style.zIndex = "10"; labelNode.style.pointerEvents = "none";
        labelNode.style.background = "rgba(10, 10, 15, 0.9)"; labelNode.style.border = "1.5px solid #00ffcc"; labelNode.style.borderRadius = "5px";
        labelNode.style.padding = "2px 6px"; labelNode.style.color = "#ffffff"; labelNode.style.fontSize = "9px"; labelNode.style.transform = "translate(-50%, -50%)";
        labelNode.textContent = "Gravitational Core";
        container.appendChild(labelNode);

        const clock = new THREE.Clock();
        let animId;

        function draw() {
          animId = requestAnimationFrame(draw);
          const elapsed = clock.getElapsedTime() * speed;

          pointCloud.scale.set(scale, scale, scale);

          const posAttr = pGeo.attributes.position;
          for (let i = 0; i < particleCount; i++) {
            const d = pData[i];
            d.angle += 0.005 * d.speed * speed;
            const x = Math.cos(d.angle) * d.radius;
            const z = Math.sin(d.angle) * d.radius;
            posAttr.setXYZ(i, x, d.yOffset + Math.sin(elapsed + d.radius) * 0.1, z);
          }
          posAttr.needsUpdate = true;

          topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Particle Paradigm: Infinite Vertex Point Cloud</div>';

          const projV = new THREE.Vector3(0, 0, 0);
          projV.project(camera);
          labelNode.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
          labelNode.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";

          controls.update();
          renderer.render(scene, camera);
        }
        draw();

        return {
          updateParams: (p) => {
            if (p.speed !== undefined) speed = Number(p.speed);
            if (p.sizeScale !== undefined) scale = Number(p.sizeScale);
          },
          destroy: () => {
            cancelAnimationFrame(animId);
            controls.dispose();
            renderer.dispose();
            if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
            if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
            if (labelNode && labelNode.parentNode) labelNode.parentNode.removeChild(labelNode);
            pointTex.dispose();
            pGeo.dispose();
            pMat.dispose();
          }
        };
      `;
    }
    else if (classification === "CONST_MOLECULAR") {
      explanation = `### Polished Atomic Molecule & Chemical Bonds
This molecular graphics simulation visualizes a three-dimensional crystalline packing lattice representing **${title}**.

#### High Quality Coordination
Forces are structured using ball-and-stick connectors matching CPK atomic spacing. The mechanical energy is formulated mathematically using atomic bonds:

$$E_{\\text{bond}} = \\sum \\frac{1}{2} k_b (r - r_0)^2 + \\sum \\frac{1}{2} k_\\theta (\\theta - \\theta_0)^2$$

Where $k_b$ and $k_\\theta$ regulate vibrational bond stretching and bending constants.

#### Covalent Lattice Models
- **Atom Cores**: Represented as CPK spheres matching covalent atomic radii.
- **Linker Bridges**: Modeled as cylinder force bonds, stabilizing the crystal geometry securely.`;

      controlsGuide = "Orbit to examine atomic structures. Slide speed to accelerate microthermal vibrations.";

      fallbackCode = `
        const width = container.clientWidth;
        const height = container.clientHeight;
        const scene = new THREE.Scene();
        scene.background = new THREE.Color("#05050e");

        const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
        camera.position.set(4, 4, 10);

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(width, height);
        container.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;

        scene.add(new THREE.AmbientLight("#151124", 1.8));
        const pl1 = new THREE.PointLight("#ff0077", 4, 30); pl1.position.set(6, 8, 6); scene.add(pl1);
        const pl2 = new THREE.PointLight("#00ffcc", 3, 30); pl2.position.set(-6, -4, -6); scene.add(pl2);

        let speed = currentParams.speed || 1.0;
        let scale = currentParams.sizeScale || 1.0;
        let isWire = currentParams.wireframe !== undefined ? currentParams.wireframe : true;

        const molecularGroup = new THREE.Group();
        scene.add(molecularGroup);

        const atoms = [];
        const bonds = [];
        const coords = [
          { pos: new THREE.Vector3(0,0,0), isCore: true, color: "#e2e8f0" },
          { pos: new THREE.Vector3(1.8, 1.2, 0), isCore: false, color: "#38bdf8" },
          { pos: new THREE.Vector3(-1.8, 1.2, 0), isCore: false, color: "#38bdf8" },
          { pos: new THREE.Vector3(0, -1.8, 1.2), isCore: false, color: "#f43f5e" },
          { pos: new THREE.Vector3(0, -1.8, -1.2), isCore: false, color: "#f43f5e" }
        ];

        coords.forEach((c, idx) => {
          const r = c.isCore ? 0.75 : 0.5;
          const geom = new THREE.SphereGeometry(r, 24, 24);
          const mat = new THREE.MeshStandardMaterial({
            color: c.color,
            roughness: 0.15,
            metalness: 0.6,
            clearcoat: 1.0
          });
          const mesh = new THREE.Mesh(geom, mat);
          mesh.position.copy(c.pos);
          molecularGroup.add(mesh);
          atoms.push({ mesh, initPos: c.pos.clone(), seed: idx * 50 });
        });

        // Bonds
        for (let i = 1; i < coords.length; i++) {
          const cyGeo = new THREE.CylinderGeometry(0.1, 0.1, 1, 12);
          const cyMat = new THREE.MeshStandardMaterial({ color: "#2d2942", roughness: 0.4 });
          const mesh = new THREE.Mesh(cyGeo, cyMat);
          molecularGroup.add(mesh);
          bonds.push({ mesh, fromIdx: 0, toIdx: i });
        }

        function updateBond(mesh, pA, pB) {
          mesh.position.copy(new THREE.Vector3().addVectors(pA, pB).multiplyScalar(0.5));
          const dir = new THREE.Vector3().subVectors(pB, pA).normalize();
          const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
          mesh.setRotationFromQuaternion(q);
          mesh.scale.set(1, pA.distanceTo(pB), 1);
        }

        const topCard = document.createElement("div");
        topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
        topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 10, 15, 0.9)";
        topCard.style.border = "1.5px solid #ff3b77"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 12px";
        topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
        container.appendChild(topCard);

        const labelNode = document.createElement("div");
        labelNode.style.position = "absolute"; labelNode.style.zIndex = "10"; labelNode.style.pointerEvents = "none";
        labelNode.style.background = "rgba(10, 10, 15, 0.9)"; labelNode.style.border = "1.5px solid #00ffcc"; labelNode.style.borderRadius = "5px";
        labelNode.style.padding = "2px 6px"; labelNode.style.color = "#ffffff"; labelNode.style.fontSize = "9px"; labelNode.style.transform = "translate(-50%, -50%)";
        labelNode.textContent = "Molecular Central Atom";
        container.appendChild(labelNode);

        const clock = new THREE.Clock();
        let animId;

        function draw() {
          animId = requestAnimationFrame(draw);
          const elapsed = clock.getElapsedTime() * speed;

          molecularGroup.scale.set(scale, scale, scale);
          molecularGroup.rotation.y = elapsed * 0.15;
          molecularGroup.rotation.z = elapsed * 0.05;

          atoms.forEach((a) => {
            const vib = Math.sin(elapsed * 10.0 + a.seed) * 0.04 * speed;
            a.mesh.position.copy(a.initPos).addScalar(vib);
          });

          bonds.forEach((b) => {
            b.mesh.visible = isWire;
            if (isWire) {
              updateBond(b.mesh, atoms[b.fromIdx].mesh.position, atoms[b.toIdx].mesh.position);
            }
          });

          topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Molecular Paradigm: Ball-and-Stick Covalent Structure</div>';

          const projV = new THREE.Vector3();
          projV.copy(atoms[0].mesh.position).applyMatrix4(molecularGroup.matrixWorld).project(camera);
          labelNode.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
          labelNode.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 20) + "px";

          controls.update();
          renderer.render(scene, camera);
        }
        draw();

        return {
          updateParams: (p) => {
            if (p.speed !== undefined) speed = Number(p.speed);
            if (p.sizeScale !== undefined) scale = Number(p.sizeScale);
            if (p.wireframe !== undefined) isWire = !!p.wireframe;
          },
          destroy: () => {
            cancelAnimationFrame(animId);
            controls.dispose();
            renderer.dispose();
            if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
            if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
            if (labelNode && labelNode.parentNode) labelNode.parentNode.removeChild(labelNode);
            scene.traverse((obj) => {
              if (obj.geometry) obj.geometry.dispose();
              if (obj.material) {
                if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
                else obj.material.dispose();
              }
            });
          }
        };
      `;
    }
    else {
      explanation = `### Procedural 3D Quantum Vector Flow & Dynamic Particle Storm
This scientific simulation models a high-density, organically morphing topological velocity vector field representing **${title}** in multidimensional coordinate space.

#### Vector Flow and Particle Transport
The system computes the trajectories of individual particle vectors, updated dynamically using continuous differential vector fields on a compact manifold:

$$\\frac{d\\mathbf{x}_i}{dt} = \\mathbf{v}(\\mathbf{x}_i, t)$$

To elicit organic vortices and chaotic turbulent curls, the velocity field $\\mathbf{v}(\\mathbf{x}, t)$ is formulated as a periodic rotational flow:

$$\\mathbf{v}(\\vec{x}, t) = R \\cdot \\left[ \\sin(\\omega y + t) \\cdot \\cos(\\alpha z), \\sin(\\omega z + t) \\cdot \\cos(\\alpha x), \\sin(\\omega x + t) \\cdot \\cos(\\alpha y) \\right]$$

#### Multi-Frequency Particle Synthesis
- **Bioluminescent Glowing Particles**: Structured using dense, additive-blending vertex arrays floating in deep cosmic space.
- **Dynamic Orbital Attractors**: Individual vertices trace continuous field streams, showing real-time fluid turbulence and chaotic curls.
- **Zero Standard Grids Constraint**: Designed cleanly as a pure, immersive quantum vector storm with no dry flat coordinate overlays, satisfying high-end production aesthetics.`;

      controlsGuide = "Orbit or drag to view the fluid dynamics. Adjust the sliders to customize speed, chaos turbulence, flow bounds, and colorShift presets.";

      interactiveParameters = [
        { name: "speed", label: "Flow Velocity", type: "slider", min: 0.1, max: 2.5, step: 0.1, default: 1.0 },
        { name: "turbulence", label: "Chaos / Turbulence", type: "slider", min: 0.1, max: 5.0, step: 0.1, default: 1.5 },
        { name: "sizeScale", label: "Flow Bounds", type: "slider", min: 0.5, max: 2.5, step: 0.1, default: 1.0 },
        { name: "colorShift", label: "Vortex Dimension (1=Teal, 2=Cyan, 3=Magenta)", type: "slider", min: 1, max: 3, step: 1, default: 2 }
      ];

      fallbackCode = `
        const width = container.clientWidth;
        const height = container.clientHeight;
        const scene = new THREE.Scene();
        scene.background = new THREE.Color("#020205");

        const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
        camera.position.set(0, 5, 12);

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(width, height);
        container.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;

        scene.add(new THREE.AmbientLight("#0a0a0f", 2.0));
        const pl1 = new THREE.PointLight("#ff00dd", 3, 30); pl1.position.set(5, 5, 5); scene.add(pl1);
        const pl2 = new THREE.PointLight("#00ffcc", 3, 30); pl2.position.set(-5, -5, -5); scene.add(pl2);

        let speed = currentParams.speed || 1.0;
        let turbulence = currentParams.turbulence !== undefined ? currentParams.turbulence : 1.5;
        let scale = currentParams.sizeScale || 1.0;
        let colorShift = currentParams.colorShift !== undefined ? Math.round(currentParams.colorShift) : 2;

        const particleCount = 4500;
        const positions = new Float32Array(particleCount * 3);
        const colors = new Float32Array(particleCount * 3);
        const pData = [];

        const tealCol = new THREE.Color("#00ffd2");
        const cyanCol = new THREE.Color("#00ebff");
        const pinkCol = new THREE.Color("#ff0077");

        for (let i = 0; i < particleCount; i++) {
          const x = (Math.random() - 0.5) * 8.0;
          const y = (Math.random() - 0.5) * 8.0;
          const z = (Math.random() - 0.5) * 8.0;
          
          positions[i * 3] = x;
          positions[i * 3 + 1] = y;
          positions[i * 3 + 2] = z;

          // Color palette logic
          let c = tealCol;
          if (i % 3 === 1) c = cyanCol;
          else if (i % 3 === 2) c = pinkCol;

          colors[i * 3] = c.r;
          colors[i * 3 + 1] = c.g;
          colors[i * 3 + 2] = c.b;

          pData.push({
            speed: 0.4 + Math.random() * 1.2,
            phaseX: Math.random() * Math.PI * 2,
            phaseY: Math.random() * Math.PI * 2,
            phaseZ: Math.random() * Math.PI * 2,
            factor: 0.5 + Math.random() * 1.5
          });
        }

        const pCanvas = document.createElement("canvas");
        pCanvas.width = 16; pCanvas.height = 16;
        const pCtx = pCanvas.getContext("2d");
        const pGrad = pCtx.createRadialGradient(8, 8, 0, 8, 8, 8);
        pGrad.addColorStop(0, "rgba(255, 255, 255, 1)");
        pGrad.addColorStop(1, "rgba(255, 255, 255, 0)");
        pCtx.fillStyle = pGrad; pCtx.fillRect(0, 0, 16, 16);
        const pointTex = new THREE.CanvasTexture(pCanvas);

        const pGeo = new THREE.BufferGeometry();
        pGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
        pGeo.setAttribute("color", new THREE.BufferAttribute(colors, 3));

        const pMat = new THREE.PointsMaterial({
          size: 0.18,
          map: pointTex,
          vertexColors: true,
          transparent: true,
          opacity: 0.9,
          blending: THREE.AdditiveBlending,
          depthWrite: false
        });

        const pointCloud = new THREE.Points(pGeo, pMat);
        scene.add(pointCloud);

        // Core attractor mesh representing the central singularity of the query
        const coreGeo = new THREE.SphereGeometry(0.8, 32, 32);
        const coreMat = new THREE.MeshStandardMaterial({
          color: "#00ffcc",
          roughness: 0.1,
          metalness: 0.9,
          transparent: true,
          opacity: 0.75,
          emissive: "#0033aa"
        });
        const coreMesh = new THREE.Mesh(coreGeo, coreMat);
        scene.add(coreMesh);

        const topCard = document.createElement("div");
        topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
        topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(5, 5, 10, 0.95)";
        topCard.style.border = "1.5px solid #00ffcc"; topCard.style.borderRadius = "10px"; topCard.style.padding = "6px 14px";
        topCard.style.fontFamily = "Inter, sans-serif"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
        container.appendChild(topCard);

        const labelNode = document.createElement("div");
        labelNode.style.position = "absolute"; labelNode.style.zIndex = "10"; labelNode.style.pointerEvents = "none";
        labelNode.style.background = "rgba(5, 5, 10, 0.95)"; labelNode.style.border = "1.5px solid #ff00dd"; labelNode.style.borderRadius = "5px";
        labelNode.style.padding = "3px 8px"; labelNode.style.color = "#ffffff"; labelNode.style.fontSize = "9px"; labelNode.style.transform = "translate(-50%, -50%)";
        labelNode.textContent = "Flow Core Singular Vortex";
        container.appendChild(labelNode);

        const clock = new THREE.Clock();
        let animId;

        function draw() {
          animId = requestAnimationFrame(draw);
          const elapsed = clock.getElapsedTime() * speed;

          pointCloud.scale.set(scale, scale, scale);
          pointCloud.rotation.y = elapsed * 0.04;
          
          coreMesh.scale.set(scale, scale, scale);
          const coreScalePulse = 1.0 + Math.sin(elapsed * 2.0) * 0.15;
          coreMesh.scale.multiplyScalar(coreScalePulse);

          // Update core emissive colors dynamically based on active parameter colorShift
          if (colorShift === 1) {
            coreMat.color.set("#00ffd2");
            coreMat.emissive.set("#002b1b");
          } else if (colorShift === 2) {
            coreMat.color.set("#00ebff");
            coreMat.emissive.set("#001a33");
          } else {
            coreMat.color.set("#ff0077");
            coreMat.emissive.set("#2b0011");
          }

          const posAttr = pGeo.attributes.position;
          const colAttr = pGeo.attributes.color;

          for (let i = 0; i < particleCount; i++) {
            const p = pData[i];
            
            // Generate periodic morphing vectors using multi-frequency curl-like dynamics
            const x = posAttr.getX(i);
            const y = posAttr.getY(i);
            const z = posAttr.getZ(i);

            // Morph particle position guidelines
            const dx = Math.sin(y * turbulence + elapsed * p.speed) * 0.02 * p.factor;
            const dy = Math.sin(z * turbulence + elapsed * p.speed) * 0.02 * p.factor;
            const dz = Math.cos(x * turbulence + elapsed * p.speed) * 0.02 * p.factor;

            let nx = x + dx;
            let ny = y + dy;
            let nz = z + dz;

            // Reset boundary constraint to keep the storm inside the flow bounds box
            const limit = 4.5 * scale;
            if (Math.abs(nx) > limit || Math.abs(ny) > limit || Math.abs(nz) > limit) {
              nx = (Math.random() - 0.5) * 6.0;
              ny = (Math.random() - 0.5) * 6.0;
              nz = (Math.random() - 0.5) * 6.0;
            }

            posAttr.setXYZ(i, nx, ny, nz);

            // Dynamically alter particle color based on position space and parameter colorShift
            let tr, tg, tb;
            if (colorShift === 1) {
              tr = 0.0; tg = 0.8 + 0.2 * Math.sin(elapsed + nx); tb = 0.6 + 0.4 * Math.cos(elapsed + ny);
            } else if (colorShift === 2) {
              tr = 0.2 + 0.3 * Math.sin(elapsed + nz); tg = 0.7; tb = 0.9;
            } else {
              tr = 0.9; tg = 0.0; tb = 0.4 + 0.4 * Math.sin(elapsed + nx * ny);
            }
            colAttr.setXYZ(i, tr, tg, tb);
          }
          posAttr.needsUpdate = true;
          colAttr.needsUpdate = true;

          topCard.innerHTML = '<div style="font-weight:700; text-transform:uppercase;">' + "${title}" + '</div><div style="font-size:10px; opacity:0.8; margin-top:2px;">Quantum Topology: High-Density Geometric Flow</div>';

          const projV = new THREE.Vector3(0, 0, 0);
          projV.project(camera);
          labelNode.style.left = (projV.x * (container.clientWidth / 2) + container.clientWidth / 2) + "px";
          labelNode.style.top = (-(projV.y * (container.clientHeight / 2)) + container.clientHeight / 2 - 25) + "px";

          controls.update();
          renderer.render(scene, camera);
        }
        draw();

        return {
          updateParams: (p) => {
            if (p.speed !== undefined) speed = Number(p.speed);
            if (p.turbulence !== undefined) turbulence = Number(p.turbulence);
            if (p.sizeScale !== undefined) scale = Number(p.sizeScale);
            if (p.colorShift !== undefined) colorShift = Math.round(Number(p.colorShift));
          },
          destroy: () => {
            cancelAnimationFrame(animId);
            controls.dispose();
            renderer.dispose();
            if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
            if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
            if (labelNode && labelNode.parentNode) labelNode.parentNode.removeChild(labelNode);
            scene.traverse((obj) => {
              if (obj.geometry) obj.geometry.dispose();
              if (obj.material) {
                if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
                else obj.material.dispose();
              }
            });
            pointTex.dispose();
            pGeo.dispose();
            pMat.dispose();
            coreGeo.dispose();
            coreMat.dispose();
          }
        };
      `;
    }
  }

  return {
    topic: title,
    explanation,
    threeJsCode: enforceNeonAndLights(fallbackCode),
    controlsGuide,
    interactiveParameters,
    isFallback: true,
    fallbackError: errorMsg
  };
}
