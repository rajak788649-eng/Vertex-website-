export interface InteractiveParameter {
  name: string;
  label: string;
  type: "slider" | "toggle";
  min?: number;
  max?: number;
  step?: number;
  default: number | boolean;
}

export interface PracticeQuestion {
  question: string;
  answer: string;
}

export interface TheoryData {
  conceptAndFormula: string;
  derivation: string;
  realLifeApplications: string[];
  practiceQuestions: PracticeQuestion[];
}

export interface ConceptSimulation {
  topic: string;
  explanation: string;
  threeJsCode: string;
  controlsGuide: string;
  interactiveParameters: InteractiveParameter[];
  theoryData?: TheoryData;
  isFallback?: boolean;
  fallbackError?: string;
}

export interface SavedHistoryItem {
  id: string;
  topic: string;
  timestamp: string;
  simulation: ConceptSimulation;
}

export interface UserProfile {
  fullName: string;
  academicRole: string;
  primaryFocus: string;
  affiliation: string;
  avatarEmoji: string;
  avatarBgColor: string;
  joinedDate: string;
}

