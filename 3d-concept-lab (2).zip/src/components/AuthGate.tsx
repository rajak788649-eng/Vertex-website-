import { motion } from "motion/react";
import { Mail, Lock, ArrowRight, Compass, ExternalLink } from "lucide-react";

interface AuthGateProps {
  email: string;
  setEmail: (email: string) => void;
  password: string;
  setPassword: (password: string) => void;
  loginError: string | null;
  setLoginError: (error: string | null) => void;
  isDemoLoading: boolean;
  unauthorizedDomain: string | null;
  copiedDomain: string | null;
  setCopiedDomain: (domain: string | null) => void;
  handleLoginSubmit: (e: React.FormEvent) => void;
  handleGoogleSignIn: () => void;
}

export function AuthGate({
  email,
  setEmail,
  password,
  setPassword,
  loginError,
  setLoginError,
  isDemoLoading,
  unauthorizedDomain,
  copiedDomain,
  setCopiedDomain,
  handleLoginSubmit,
  handleGoogleSignIn,
}: AuthGateProps) {
  return (
    <motion.div
      key="login-gate"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-[#05050a] flex flex-col justify-center items-center p-4 relative overflow-hidden text-neutral-100 selection:bg-indigo-500/30 selection:text-indigo-200"
    >
      {/* Background Ambient Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-700/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Cyberpunk Grid Backdrop */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-40 pointer-events-none" />

      {/* Centered Glassmorphic login card */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, type: "spring", stiffness: 80 }}
        className="w-full max-w-md bg-neutral-900/40 backdrop-blur-xl border border-neutral-850 p-8 rounded-2xl shadow-2xl relative z-10 flex flex-col gap-6"
      >
        {/* Top aesthetic ambient highlight line */}
        <div className="absolute -top-[1px] inset-x-12 h-[2px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent" />

        {/* Logo, title and description */}
        <div className="flex flex-col items-center text-center">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-tr from-indigo-500 via-sky-500 to-emerald-500 p-[1.5px] shadow-lg shadow-indigo-500/20 mb-3">
            <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
              <Compass className="w-7 h-7 text-indigo-400 rotate-12" />
            </div>
          </div>
          <h2 className="text-2xl font-display font-black text-white tracking-tight flex items-center gap-1.5 justify-center">
            Vertex
          </h2>
          <p className="text-xs text-neutral-400 mt-1 font-sans">
            Interactive Physics & Math Laboratory Panel
          </p>
        </div>

        {/* Login fields inside form */}
        <form onSubmit={handleLoginSubmit} className="flex flex-col gap-4">
          {/* Email Field */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-semibold text-neutral-400 tracking-wider uppercase block">
              Email Address
            </label>
            <div className="relative">
              <span className="absolute left-3 leading-none top-1/2 -translate-y-1/2 text-neutral-500">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                placeholder="doctor.physic@lab.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-neutral-950/60 text-sm py-2.5 pl-10 pr-4 rounded-xl border border-neutral-800 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/40 transition-all font-sans placeholder:text-neutral-600 text-neutral-200 shadow-inner"
                disabled={isDemoLoading}
              />
            </div>
          </div>

          {/* Password Field */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-semibold text-neutral-400 tracking-wider uppercase block">
              Password
            </label>
            <div className="relative">
              <span className="absolute left-3 leading-none top-1/2 -translate-y-1/2 text-neutral-500">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-neutral-950/60 text-sm py-2.5 pl-10 pr-4 rounded-xl border border-neutral-800 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/40 transition-all font-sans placeholder:text-neutral-600 text-neutral-200 shadow-inner"
                disabled={isDemoLoading}
              />
            </div>
          </div>

          {/* Validation Feedbacks */}
          {loginError && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-red-950/35 border border-red-900/60 rounded-xl text-neutral-300 text-left font-sans leading-relaxed space-y-3"
            >
              <div className="flex items-start gap-1.5 text-xs font-semibold text-red-400">
                <span>⚠️</span>
                <span>Authentication Alert</span>
              </div>
              <p className="text-xs text-red-200/90 leading-normal">
                {loginError}
              </p>

              {unauthorizedDomain && (
                <div className="mt-3 pt-3 border-t border-red-900/30 space-y-2.5 text-xs text-neutral-300">
                  <p className="font-bold text-cyan-400 uppercase tracking-wide text-[10px] flex items-center gap-1">
                    🔧 Action Steps (Authorize Domain):
                  </p>
                  <p className="text-[11px] text-neutral-400 font-sans leading-normal">
                    Firebase blocks third-party Google Auth popups outside designated hosting domains. Please register your workspace domain:
                  </p>
                  
                  {/* Copyable hostnames */}
                  <div className="space-y-1.5 font-mono text-[11px]">
                    <div className="flex items-center justify-between bg-neutral-950/80 p-2 rounded border border-neutral-800">
                      <code className="text-cyan-400 select-all font-bold truncate pr-2">{unauthorizedDomain}</code>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(unauthorizedDomain);
                          setCopiedDomain("sandbox");
                          setTimeout(() => setCopiedDomain(null), 2000);
                        }}
                        className="text-neutral-500 hover:text-cyan-400 text-[10px] active:scale-95 transition-all cursor-pointer underline decoration-dotted shrink-0"
                      >
                        {copiedDomain === "sandbox" ? "✓ Copied!" : "Copy Domain"}
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-between bg-neutral-950/80 p-2 rounded border border-neutral-800">
                      <code className="text-cyan-400 select-all font-bold">localhost</code>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText("localhost");
                          setCopiedDomain("local");
                          setTimeout(() => setCopiedDomain(null), 2000);
                        }}
                        className="text-neutral-500 hover:text-cyan-400 text-[10px] active:scale-95 transition-all cursor-pointer underline decoration-dotted shrink-0"
                      >
                        {copiedDomain === "local" ? "✓ Copied!" : "Copy Domain"}
                      </button>
                    </div>
                  </div>

                  {/* Step list instructions with link */}
                  <ol className="list-decimal list-inside space-y-1.5 pl-1 text-[11px] text-neutral-400 leading-normal font-sans">
                    <li>Open the <a href="https://console.firebase.google.com/" target="_blank" rel="noreferrer" className="text-cyan-400 hover:text-cyan-300 underline decoration-dotted font-semibold inline-flex items-center gap-0.5">Firebase Console <ExternalLink className="w-3 h-3 inline" /></a></li>
                    <li>Select your project: <span className="text-neutral-300 font-mono">dconcept-lab</span></li>
                    <li>Navigate to <span className="text-neutral-200">Authentication</span> &rarr; <span className="text-neutral-200">Settings</span> &rarr; <span className="text-neutral-200">Authorized domains</span></li>
                    <li>Click <span className="text-neutral-200">"Add domain"</span> and paste the copied URL</li>
                  </ol>
                </div>
              )}
            </motion.div>
          )}

          {/* Submit Enter Button */}
          <button
            type="submit"
            disabled={isDemoLoading}
            className="w-full font-display font-semibold uppercase tracking-wider text-xs py-3 mt-1.5 rounded-xl bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-600 hover:from-cyan-400 hover:via-indigo-400 hover:to-purple-500 active:scale-[0.98] transition-all cursor-pointer text-white shadow-xl shadow-cyan-950/40 relative overflow-hidden group flex items-center justify-center gap-1.5"
          >
            <span className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            Enter Laboratory
            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
          </button>
        </form>

        {/* Google Sign-in Styled Button */}
        <div className="flex flex-col gap-3">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-neutral-800/80"></div>
            </div>
            <div className="relative flex justify-center text-[9px] uppercase">
              <span className="bg-[#050512] px-2 text-neutral-500 font-mono tracking-widest">
                Or secure session
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={isDemoLoading}
            className="w-full py-2.5 px-4 bg-neutral-950/40 hover:bg-neutral-950/90 border border-neutral-800 hover:border-neutral-700 rounded-xl text-xs text-neutral-300 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2 font-medium disabled:opacity-50"
          >
            {isDemoLoading ? (
              <span className="w-3.5 h-3.5 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/>
              </svg>
            )}
            {isDemoLoading ? "Connecting..." : "Sign in with Google Account"}
          </button>
        </div>

        {/* Credit attribution footer */}
        <div className="border-t border-neutral-900 pt-4 text-center text-[10px] text-neutral-500 font-mono tracking-wider">
          Designed & Developed by <span className="text-cyan-400 font-bold">Raushan Kumar</span> <span className="text-neutral-700">|</span> <span className="text-neutral-400">Vertex</span>
        </div>
      </motion.div>
    </motion.div>
  );
}
