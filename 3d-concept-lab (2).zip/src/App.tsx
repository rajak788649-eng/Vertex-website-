import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Search,
  Sparkles,
  Compass,
  Code,
  BookOpen,
  Copy,
  Check,
  History,
  Trash2,
  Sliders,
  HelpCircle,
  Lightbulb,
  ExternalLink,
  RefreshCw,
  AlertTriangle,
  User
} from "lucide-react";
import { MathMarkdown } from "./components/MathMarkdown";
import { initializeApp } from "firebase/app";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from "firebase/auth";
import { DEFAULT_PRESETS } from "./data/defaultPresets";
import { ConceptSimulation, SavedHistoryItem } from "./types";
import ThreeScenePlayer from "./components/ThreeScenePlayer";
import UserProfileModal from "./components/UserProfileModal";
import { AuthGate } from "./components/AuthGate";

// Production Firebase Configuration using exact credential keys
const firebaseConfig = {
  apiKey: "AIzaSyBHU4DZZi3TO7d1Eli8KLkF1m8JfLvexZw",
  authDomain: "dconcept-lab.firebaseapp.com",
  projectId: "dconcept-lab",
  storageBucket: "dconcept-lab.firebasestorage.app",
  messagingSenderId: "790591782228",
  appId: "1:790591782228:web:66e0bcfe8e86e1d3c69cc1",
  measurementId: "G-QL8QC5371W"
};

// Initialize Firebase App & Auth
const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);

export default function App() {
  // Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAuthChecking, setIsAuthChecking] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isDemoLoading, setIsDemoLoading] = useState(false);
  const [unauthorizedDomain, setUnauthorizedDomain] = useState<string | null>(null);
  const [copiedDomain, setCopiedDomain] = useState<string | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Concept Lab States
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStatusIndex, setLoadingStatusIndex] = useState(0);
  const [currentPrompt, setCurrentPrompt] = useState("");
  
  // Initialize with Coulomb's Law as the interactive default lab
  const [simulation, setSimulation] = useState<ConceptSimulation>(DEFAULT_PRESETS.coulomb || DEFAULT_PRESETS.lorenz);
  const [params, setParams] = useState<Record<string, number | boolean>>({});
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"render" | "code">("render");
  const [history, setHistory] = useState<SavedHistoryItem[]>(() => {
    try {
      const cached = localStorage.getItem("three_sec_history");
      return cached ? JSON.parse(cached) : [];
    } catch (e) {
      console.warn("Failed to parse history from cache", e);
      return [];
    }
  });
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [thinkingMode, setThinkingMode] = useState(false);

  // Maritime detector — when query matches, show Sketchfab embed instead of Gemini simulation
  const MARITIME_KEYWORDS = ["ship", "boat", "vessel", "maritime", "buoy", "anchor", "hull", "submarine", "ferry", "yacht", "cargo ship", "tanker", "lighthouse", "dock", "navy", "tugboat", "destroyer", "frigate", "sailboat", "titanic", "carrier", "cruiser"];
  const isMaritimeTopic = (query: string) => {
    const q = query.toLowerCase().trim();
    // Broaden matching for any sketchfab-related queries, ships, or common typos
    if (
      q.includes("sketchfab") || 
      q.includes("setchfab") || 
      q.includes("sketch") || 
      q.includes("setch") ||
      q.includes("ship3d") ||
      q.includes("3dship")
    ) {
      return true;
    }
    return MARITIME_KEYWORDS.some((kw) => q.includes(kw));
  };
  const [showSketchfab, setShowSketchfab] = useState(false);

  const loadingStatuses = [
    "Analyzing physics laws & coordinates...",
    "Drafting reactive variables & sliders...",
    "Generating Three.js WebGL matrices...",
    "Injecting Euler and Verlet integration formulas...",
    "Finishing procedural textures & lighting...",
    "Readying interactive 3D laboratory stage..."
  ];

  // Rotate loading statuses periodically to delight users while waiting
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isLoading) {
      setLoadingStatusIndex(0);
      interval = setInterval(() => {
        setLoadingStatusIndex((prev) => (prev + 1) % loadingStatuses.length);
      }, 3500);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  // Sync parameters state when active simulation changes
  useEffect(() => {
    if (simulation) {
      const initialParams: Record<string, number | boolean> = {};
      simulation.interactiveParameters.forEach((p) => {
        initialParams[p.name] = p.default;
      });
      // Always guarantee interactionSensitivity parameter starts at 1.0
      if (initialParams["interactionSensitivity"] === undefined) {
        initialParams["interactionSensitivity"] = 1.0;
      }
      setParams(initialParams);
    }
  }, [simulation]);

  // Save history to disk
  const saveToHistory = (sim: ConceptSimulation) => {
    setHistory((prev) => {
      const filtered = prev.filter((item) => item.topic.toLowerCase() !== sim.topic.toLowerCase());
      const updated = [
        {
          id: String(Date.now()),
          topic: sim.topic,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          simulation: sim,
        },
        ...filtered,
      ].slice(0, 10); // Keep last 10
      localStorage.setItem("three_sec_history", JSON.stringify(updated));
      return updated;
    });
  };

  // Handle preset clicks
  const loadPreset = (presetKey: string) => {
    if (DEFAULT_PRESETS[presetKey]) {
      setSimulation(DEFAULT_PRESETS[presetKey]);
      setCopied(false);
      setErrorMessage(null);
      setShowSketchfab(false);
    }
  };

  // Submit search request to our proxy server
  const handleSearch = async (e?: React.FormEvent, customTopic?: string, forceFresh?: boolean) => {
    if (e) e.preventDefault();
    const targetTopic = (customTopic || searchQuery).trim();
    if (!targetTopic) return;

    setIsLoading(true);
    setErrorMessage(null);
    setCopied(false);
    setCurrentPrompt(targetTopic);

    // Maritime shortcut — skip Gemini, show Sketchfab embed directly
    if (isMaritimeTopic(targetTopic)) {
      setShowSketchfab(true);
      setIsLoading(false);
      setSearchQuery("");
      return;
    }

    setShowSketchfab(false);

    try {
      const res = await fetch("/api/explain-and-render", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: targetTopic, forceFresh: !!forceFresh, thinkingMode }),
      });

      if (!res.ok) {
        throw new Error(`Server returned error status: ${res.status}`);
      }

      const data: ConceptSimulation = await res.json();
      
      setSimulation(data);
      saveToHistory(data);
      setSearchQuery(""); // Clear bar on success
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "Failed to trigger Gemini generation. Please verify your connection.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(simulation.threeJsCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const deleteHistoryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      localStorage.setItem("three_sec_history", JSON.stringify(updated));
      return updated;
    });
  };

  // Monitor login status automatically and enforce local session retention
  useEffect(() => {
    let unsubscribe: (() => void) | null = null;

    // Explicitly configure browserLocalPersistence to keep sessions active permanently
    setPersistence(auth, browserLocalPersistence)
      .then(() => {
        console.log("Firebase local storage persistence established.");
        unsubscribe = onAuthStateChanged(auth, (user) => {
          if (user) {
            setIsLoggedIn(true);
            setEmail(user.email || "");
          } else {
            setIsLoggedIn(false);
            setEmail("");
          }
          setIsAuthChecking(false);
        });
      })
      .catch((err) => {
        console.error("Firebase persistence setup failed:", err);
        // Fallback: subscribe to auth state changes directly
        unsubscribe = onAuthStateChanged(auth, (user) => {
          if (user) {
            setIsLoggedIn(true);
            setEmail(user.email || "");
          } else {
            setIsLoggedIn(false);
            setEmail("");
          }
          setIsAuthChecking(false);
        });
      });

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, []);

  // Login & Sign up handler
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setUnauthorizedDomain(null);
    setIsDemoLoading(true);

    // Basic Validation
    if (!email.trim()) {
      setLoginError("Please enter your Email Address.");
      setIsDemoLoading(false);
      return;
    }
    if (!email.includes("@") || !email.includes(".")) {
      setLoginError("Please enter a valid Email Address.");
      setIsDemoLoading(false);
      return;
    }
    if (!password.trim()) {
      setLoginError("Please enter your Password.");
      setIsDemoLoading(false);
      return;
    }
    if (password.length < 6) {
      setLoginError("Password must be at least 6 characters.");
      setIsDemoLoading(false);
      return;
    }

    try {
      await setPersistence(auth, browserLocalPersistence);
      // Real sign-in lookup only, registration removed
      await signInWithEmailAndPassword(auth, email, password);
      setIsLoggedIn(true);
    } catch (err: any) {
      console.error("Firebase auth error:", err);
      let friendlyMessage = err.message || "An authentication error occurred.";
      if (err.code === "auth/invalid-credential" || err.code === "auth/user-not-found" || err.code === "auth/wrong-password") {
        friendlyMessage = "Incorrect email address or security key password.";
      } else if (err.code === "auth/email-already-in-use") {
        friendlyMessage = "This email is already registered. Please Switch to Login mode instead.";
      } else if (err.code === "auth/weak-password") {
        friendlyMessage = "Password must be at least 6 characters.";
      } else if (err.code === "auth/invalid-email") {
        friendlyMessage = "Please use a valid email address.";
      } else if (err.code === "auth/unauthorized-domain") {
        friendlyMessage = "Google Authentication requires your preview domain namespace to be white-listed. Please add this hosting endpoint as an authorized domain in your Firebase Authentication configuration.";
        setUnauthorizedDomain(window.location.hostname);
      }
      setLoginError(friendlyMessage);
    } finally {
      setIsDemoLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoginError(null);
    setUnauthorizedDomain(null);
    setIsDemoLoading(true);
    
    try {
      await setPersistence(auth, browserLocalPersistence);
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      setIsLoggedIn(true);
    } catch (err: any) {
      console.error("Firebase Google Popup error:", err);
      let friendlyMessage = err.message || "Google Authentication failed.";
      if (err.code === "auth/popup-closed-by-user") {
        friendlyMessage = "Google Sign-In canceled before completion.";
      } else if (err.code === "auth/unauthorized-domain") {
        friendlyMessage = "Google Authentication requires your preview domain namespace to be white-listed. Please add this hosting endpoint as an authorized domain in your Firebase Authentication configuration.";
        setUnauthorizedDomain(window.location.hostname);
      }
      setLoginError(friendlyMessage);
    } finally {
      setIsDemoLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setIsLoggedIn(false);
      setEmail("");
      setPassword("");
    } catch (err: any) {
      console.error("Firebase sign out error:", err);
    }
  };

  if (isAuthChecking) {
    return (
      <div className="min-h-screen bg-[#05050a] flex flex-col justify-center items-center p-4 relative overflow-hidden text-neutral-100">
        {/* Background Ambient Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-700/10 rounded-full blur-[120px] pointer-events-none" />

        {/* Cyberpunk Grid Backdrop */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-40 pointer-events-none" />

        {/* Pulsing Outer Atom/Orb */}
        <div className="relative z-10 flex flex-col items-center gap-4">
          <div className="relative w-16 h-16 flex items-center justify-center">
            {/* Pulsing ring */}
            <div className="absolute inset-0 border-2 border-cyan-500/20 rounded-full animate-ping duration-1000" />
            <div className="absolute inset-1 border-2 border-indigo-500/30 rounded-full animate-pulse" />
            {/* Spinning ring */}
            <div className="absolute inset-0 border-2 border-transparent border-t-indigo-400 border-r-cyan-400 rounded-full animate-spin" />
            
            <Compass className="w-6 h-6 text-indigo-400" />
          </div>
          
          <div className="text-center space-y-1">
            <h3 className="text-xs font-display font-bold uppercase tracking-widest text-neutral-200">
              Synchronizing Lab Session
            </h3>
            <p className="text-[10px] text-neutral-500 font-mono tracking-wider">
              VERIFYING AUTHENTICATION STATE...
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      {!isLoggedIn ? (
        <AuthGate
          email={email}
          setEmail={setEmail}
          password={password}
          setPassword={setPassword}
          loginError={loginError}
          setLoginError={setLoginError}
          isDemoLoading={isDemoLoading}
          unauthorizedDomain={unauthorizedDomain}
          copiedDomain={copiedDomain}
          setCopiedDomain={setCopiedDomain}
          handleLoginSubmit={handleLoginSubmit}
          handleGoogleSignIn={handleGoogleSignIn}
        />
      ) : (
        <motion.div
          key="application-stage"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="min-h-screen bg-[#05050a] flex flex-col antialiased text-neutral-100 selection:bg-indigo-500/30 selection:text-indigo-200"
        >
          {/* Background radial atmosphere */}
          <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-950/20 via-neutral-950 to-neutral-950 pointer-events-none z-0" />

          {/* Main Header */}
          <header className="sticky top-0 z-40 border-b border-neutral-900 bg-neutral-950/80 backdrop-blur-md">
            <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-indigo-500 via-sky-500 to-emerald-500 p-[1.5px] shadow-lg shadow-indigo-500/10">
                  <div className="w-full h-full bg-neutral-950 rounded-[7px] flex items-center justify-center">
                    <Compass className="w-5 h-5 text-indigo-400 animate-spin-slow" />
                  </div>
                </div>
                <div>
                  <h1 className="text-lg font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-neutral-50 via-neutral-100 to-indigo-200 tracking-tight flex items-center gap-2">
                    Vertex
                  </h1>
                  <p className="text-[11px] text-neutral-400 font-sans tracking-wide">
                    Interactive Math & Science Laboratory
                  </p>
                </div>
              </div>

              {/* Quick topic trigger input */}
              <form onSubmit={handleSearch} className="flex-1 max-w-lg relative group">
                <input
                  type="text"
                  placeholder="Query any STEM topic... (e.g. Double Pendulum, Wave optics, Orbit Distortion)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-neutral-900/60 text-sm py-2 pl-4 pr-11 rounded-full border border-neutral-800 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/50 transition-all font-sans placeholder:text-neutral-500 text-neutral-200"
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  disabled={isLoading || !searchQuery.trim()}
                  className="absolute right-1 leading-none top-1/2 -translate-y-1/2 p-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 transition-colors text-white rounded-full shadow-md cursor-pointer flex items-center justify-center"
                  title="Generate 3D concept"
                >
                  <Search className="w-4 h-4" />
                </button>
              </form>

              {/* Auth details, Profile & Sign out */}
              <div className="flex items-center gap-2.5">
                {/* Thinking Mode Toggle / Model Indicator */}
                <button
                  type="button"
                  onClick={() => setThinkingMode(!thinkingMode)}
                  className={`flex items-center gap-1.5 px-3 py-1 border rounded-full text-xs font-medium cursor-pointer transition-all duration-300 ${
                    thinkingMode
                      ? "bg-amber-950/40 border-amber-500/50 text-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.2)]"
                      : "bg-indigo-950/20 border-indigo-900/30 text-indigo-400 hover:border-indigo-500/50"
                  }`}
                  title={thinkingMode ? "Thinking Mode Active: Using gemini-3.1-pro-preview" : "Standard Mode Active: Using gemini-3.5-flash"}
                >
                  <Sparkles className={`w-3.5 h-3.5 ${thinkingMode ? "text-amber-400 animate-pulse" : "text-indigo-400"}`} />
                  <span>{thinkingMode ? "Thinking: 3.1 Pro" : "Gemini Flash Enabled"}</span>
                </button>
                
                {/* User Profile Trigger Button */}
                <button
                  onClick={() => setIsProfileOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 hover:bg-neutral-850 hover:border-cyan-500/40 border border-neutral-800 text-neutral-200 hover:text-cyan-400 font-display font-medium text-xs rounded-xl cursor-pointer transition-all shrink-0 shadow-sm"
                  title="Open Scientific Command Profile"
                >
                  <User className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Profile</span>
                </button>
              </div>
            </div>
          </header>

          {/* Main Container */}
          <main className="flex-1 max-w-7xl w-full mx-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start relative z-10">
            
            {/* Left Side: Simulation Controls & Trigger Presets (8 cols) */}
            <section className="lg:col-span-8 flex flex-col gap-4">
              
              {/* Quick Suggestions Shelf */}
              <div className="glass-panel p-3 rounded-xl border border-neutral-900 flex flex-col gap-2">
                <div className="flex items-center gap-1.5 text-xs text-neutral-400 font-semibold font-display tracking-wider uppercase mb-1">
                  <Compass className="w-3.5 h-3.5 text-indigo-400" />
                  Interactive Scientific Workbenches
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => loadPreset("maritime")}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 ${
                      simulation.topic.includes("Stability") || simulation.topic.includes("Hydrostatics") || simulation.topic.includes("Archimedes")
                        ? "bg-indigo-900/30 border-indigo-500/50 text-indigo-300"
                        : "bg-neutral-900/55 border-neutral-800/80 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-900"
                    }`}
                  >
                    🚢 Ship Stability & Hydrostatics
                  </button>
                  <button
                    onClick={() => loadPreset("gravity")}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 ${
                      simulation.topic.includes("Gravity") || simulation.topic.includes("Planetary")
                        ? "bg-indigo-900/30 border-indigo-500/50 text-indigo-300"
                        : "bg-neutral-900/55 border-neutral-800/80 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-900"
                    }`}
                  >
                    🪐 Kepler Gravity Orbits
                  </button>
                  <button
                    onClick={() => loadPreset("wave")}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 ${
                      simulation.topic.includes("Double-Slit")
                        ? "bg-indigo-900/30 border-indigo-500/50 text-indigo-300"
                        : "bg-neutral-900/55 border-neutral-800/80 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-900"
                    }`}
                  >
                    🌊 Wave Interference
                  </button>
                  <button
                    onClick={() => loadPreset("coulomb")}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 ${
                      simulation.topic.includes("Coulomb")
                        ? "bg-indigo-900/30 border-indigo-500/50 text-indigo-300"
                        : "bg-neutral-900/55 border-neutral-800/80 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-900"
                    }`}
                  >
                    ⚡ Coulomb Electric Force
                  </button>

                  <span className="h-4 w-[1px] bg-neutral-800 self-center" />

                  {/* Quick Prompt Ideas */}
                  <button
                    onClick={() => handleSearch(undefined, "Double Pendulum chaos")}
                    disabled={isLoading}
                    className="text-xs px-3 py-1.5 rounded-lg bg-neutral-900/30 border border-dashed border-neutral-800 text-neutral-400 hover:border-indigo-500/55 hover:text-indigo-300 transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3 text-indigo-400 animate-pulse" />
                    Double Pendulum
                  </button>
                  <button
                    onClick={() => handleSearch(undefined, "Fourier Series wave synthesis")}
                    disabled={isLoading}
                    className="text-xs px-3 py-1.5 rounded-lg bg-neutral-900/30 border border-dashed border-neutral-800 text-neutral-400 hover:border-indigo-500/55 hover:text-indigo-300 transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3 text-indigo-400 animate-pulse" />
                    Fourier Waves
                  </button>
                  <button
                    onClick={() => handleSearch(undefined, "Crystalline Lattice atomic geometry")}
                    disabled={isLoading}
                    className="text-xs px-3 py-1.5 rounded-lg bg-neutral-900/30 border border-dashed border-neutral-800 text-neutral-400 hover:border-indigo-500/55 hover:text-indigo-300 transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3 text-indigo-400 animate-pulse" />
                    Atomic Lattice
                  </button>
                </div>
              </div>

              {/* ── MARITIME MODE: Sketchfab Embed ── */}
              {showSketchfab && !isLoading && (
                <div className="glass-panel rounded-xl overflow-hidden border border-cyan-900/40 flex flex-col shadow-2xl">
                  {/* Header */}
                  <div className="flex items-center justify-between px-4 py-2 bg-neutral-900/45 border-b border-neutral-900">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
                      <span className="text-sm font-semibold font-display text-neutral-200">
                        🚢 Maritime 3D Models
                      </span>
                    </div>
                    <button
                      onClick={() => setShowSketchfab(false)}
                      className="text-[11px] px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-red-400 hover:border-red-500/40 transition-all cursor-pointer"
                    >
                      ✕ Close
                    </button>
                  </div>
                  {/* Sketchfab iframe */}
                  <div className="w-full bg-black" style={{ aspectRatio: "4/3" }}>
                    <iframe
                      title="Maritime assets"
                      src="https://sketchfab.com/playlists/embed?collection=97b6b7133b934ffc84809708851d8fc3&autostart=0"
                      frameBorder="0"
                      allowFullScreen
                      allow="autoplay; fullscreen; xr-spatial-tracking"
                      className="w-full h-full"
                      style={{ minHeight: 420 }}
                    />
                  </div>
                  {/* Info bar */}
                  <div className="px-4 py-2.5 bg-cyan-950/20 border-t border-cyan-900/30 text-[11px] text-cyan-400 flex items-center gap-2">
                    <span>🌊</span>
                    <span>Touch &amp; drag to rotate · Scroll to zoom · Tap thumbnails to switch models</span>
                  </div>
                </div>
              )}

              {/* ── NORMAL SIMULATION STAGE ── */}
              {!showSketchfab && <AnimatePresence mode="wait">
                {isLoading && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="glass-panel p-12 rounded-xl flex flex-col items-center justify-center border border-indigo-500/20 text-center gap-4 min-h-[450px]"
                  >
                    <div className="relative">
                      <div className="absolute inset-0 bg-indigo-500/20 blur-xl rounded-full" />
                      <div className="relative w-16 h-16 border-4 border-indigo-500/20 border-t-indigo-500 border-b-cyan-500 rounded-full animate-spin flex items-center justify-center">
                        <Compass className="w-6 h-6 text-indigo-400 animate-pulse" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-display font-bold text-neutral-100 flex items-center justify-center gap-2">
                        <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
                        Spawning 3D Concept Model
                      </h3>
                      <p className="text-sm text-neutral-400 font-mono mt-1 max-w-sm mx-auto h-12 flex items-center justify-center">
                        {loadingStatuses[loadingStatusIndex]}
                      </p>
                    </div>
                    <div className="w-64 h-1.5 bg-neutral-900 rounded-full overflow-hidden border border-neutral-800 mt-2">
                      <motion.div
                        className="h-full bg-gradient-to-r from-indigo-500 to-cyan-500"
                        initial={{ width: "0%" }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 15, ease: "linear" }}
                      />
                    </div>
                    <p className="text-xs text-neutral-500 max-w-xs font-sans">
                      The server is querying Gemini to generate highly polished math formulas and dynamic Three.js rendering code.
                    </p>
                  </motion.div>
                )}

                {!isLoading && errorMessage && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="p-6 bg-red-950/20 border border-red-900/40 rounded-xl text-center flex flex-col items-center gap-3"
                  >
                    <div className="w-12 h-12 rounded-full bg-red-500/10 flex items-center justify-center text-red-400">
                      ⚠️
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-red-200">Simulation Generation Failed</h3>
                      <p className="text-sm text-red-300 mt-1 max-w-md mx-auto">{errorMessage}</p>
                    </div>
                    <button
                      onClick={() => handleSearch()}
                      className="px-4 py-1.5 bg-red-900/40 hover:bg-red-950/60 border border-red-500/30 text-red-200 rounded-lg text-xs cursor-pointer transition-colors"
                    >
                      Retry request
                    </button>
                  </motion.div>
                )}

                {/* Simulated Stage & Code view Card */}
                {!isLoading && !errorMessage && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="glass-panel rounded-xl overflow-hidden border border-neutral-900 flex flex-col shadow-2xl relative"
                  >
                    {/* Sticky container for Mobile 3D Stage (occupies about ~40% of viewport) */}
                    <div className="sticky top-[61px] md:relative md:top-0 z-30 bg-[#08080d] border-b border-neutral-900/80 md:border-b-0 shadow-lg md:shadow-none">
                      {/* Visual Stage tabs */}
                      <div className="flex items-center justify-between px-4 py-2 bg-neutral-900/45 border-b border-neutral-900">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                          <span className="text-sm font-semibold font-display text-neutral-200">
                            {simulation.topic}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleSearch(undefined, currentPrompt, true)}
                            disabled={isLoading || !currentPrompt}
                            className="text-[11px] px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-indigo-400 hover:border-indigo-500/50 disabled:opacity-40 transition-all flex items-center gap-1.5 cursor-pointer"
                            title="Regenerate this simulation with completely fresh AI instructions"
                          >
                            <RefreshCw className={`w-3 h-3 ${isLoading ? "animate-spin text-indigo-500" : ""}`} />
                            <span className="hidden sm:inline">Regenerate Fresh</span>
                          </button>
                          
                          <div className="flex items-center gap-1 bg-[#101017] p-1 rounded-lg border border-neutral-800">
                            <button
                              onClick={() => setActiveTab("render")}
                              className={`text-xs px-3 py-1 rounded-md font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                                activeTab === "render"
                                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/10"
                                  : "text-neutral-400 hover:text-neutral-200"
                              }`}
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                              3D Interactive Stage
                            </button>
                            <button
                              onClick={() => setActiveTab("code")}
                              className={`text-xs px-3 py-1 rounded-md font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                                activeTab === "code"
                                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/10"
                                  : "text-neutral-400 hover:text-neutral-200"
                              }`}
                            >
                              <Code className="w-3.5 h-3.5" />
                              Three.js Source
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Sub Stage Area */}
                      <div className="p-3 md:p-4 bg-[#08080d]">
                        {simulation.isFallback && (
                          <div className="mb-4 p-3.5 bg-amber-950/20 border border-amber-500/20 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm relative">
                            <div className="flex items-start gap-3">
                              <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg shrink-0 mt-0.5">
                                <AlertTriangle className="w-4 h-4 animate-bounce" />
                              </div>
                              <div className="space-y-1">
                                <h4 className="text-xs font-semibold text-amber-300 flex items-center gap-1.5 font-display">
                                  Procedural Safeguard Mode Active
                                </h4>
                                <p className="text-[11px] text-amber-400/80 leading-relaxed max-w-[650px] font-sans">
                                  The Gemini API returned a load or quota limit. To ensure a persistent experience, we loaded a high-fidelity pre-bundled mathematical fallback model instead.
                                </p>
                                {simulation.fallbackError && (
                                  <details className="text-[10px] text-amber-500/60 font-mono mt-1 hover:text-amber-500 transition-colors cursor-pointer outline-none">
                                    <summary className="list-none hover:underline focus:outline-none">Show Technical Traceback</summary>
                                    <div className="mt-1 p-2 bg-black/40 rounded border border-amber-500/10 select-all overflow-x-auto max-w-full">
                                      {simulation.fallbackError}
                                    </div>
                                  </details>
                                )}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleSearch(undefined, currentPrompt, true)}
                              disabled={isLoading}
                              className="self-start md:self-center bg-amber-500/10 hover:bg-amber-500/15 border border-amber-500/30 hover:border-amber-500/50 text-amber-300 font-medium text-[11px] px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-40 shrink-0"
                            >
                              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin text-amber-400" : ""}`} />
                              Force Retry API Generation
                            </button>
                          </div>
                        )}

                        {activeTab === "render" ? (
                          <ThreeScenePlayer
                            code={simulation.threeJsCode}
                            params={params}
                            onError={(err) => console.log("Player error:", err)}
                            topic={simulation.topic}
                          />
                        ) : (
                          <div className="relative group">
                            <div className="absolute top-3 right-3 z-10 flex gap-2">
                              <button
                                onClick={handleCopyCode}
                                className="px-3 py-1.5 bg-neutral-900/90 border border-neutral-800 hover:bg-neutral-800 rounded-lg text-xs text-neutral-300 transition-all flex items-center gap-1 cursor-pointer hover:border-neutral-700"
                                title="Copy dynamic JavaScript code"
                              >
                                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400 animate-pulse" /> : <Copy className="w-3.5 h-3.5" />}
                                {copied ? "Copied!" : "Copy Code"}
                              </button>
                            </div>
                            <pre className="p-5 bg-neutral-950 border border-neutral-900 rounded-xl overflow-x-auto text-[11px] font-mono leading-relaxed h-[450px] text-zinc-400 scrollbar-thin">
                              <code>{simulation.threeJsCode}</code>
                            </pre>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Parameter Control Sliders Panel */}
                    <div className="p-4 bg-neutral-950/80 border-t border-neutral-900/60">
                      <div className="flex items-center justify-between mb-4 border-b border-neutral-900 pb-2">
                        <div className="flex items-center gap-1.5 font-sans">
                          <Sliders className="w-4 h-4 text-indigo-400" />
                          <h4 className="text-xs font-display font-semibold text-neutral-300 tracking-wider uppercase">
                            Dynamic Parameter Console
                          </h4>
                        </div>
                        <span className="text-[10px] text-neutral-500 font-mono hidden sm:inline">
                          Warping physical constants live
                        </span>
                      </div>

                      {(() => {
                        const paramsList = [...simulation.interactiveParameters];
                        // Always inject permanent Interaction Sensitivity multiplier slider if not present
                        if (!paramsList.some((p) => p.name === "interactionSensitivity")) {
                          paramsList.push({
                            name: "interactionSensitivity",
                            label: "Interaction Sensitivity",
                            type: "slider",
                            min: 0.1,
                            max: 2.0,
                            step: 0.1,
                            default: 1.0,
                          });
                        }

                        return (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3.5 max-h-[30vh] md:max-h-none overflow-y-auto pr-1 scrollbar-thin">
                            {paramsList.map((p) => (
                              <div
                                key={p.name}
                                className="flex flex-col gap-1 px-3 py-2 rounded-lg bg-neutral-900/25 border border-neutral-900 hover:border-neutral-800 transition-colors"
                              >
                                <div className="flex items-center justify-between text-xs text-neutral-300 font-sans">
                                  <span className="font-medium text-neutral-200">{p.label}</span>
                                  <span className="font-mono text-[11px] text-sky-400 bg-sky-950/30 px-1.5 py-0.5 rounded border border-sky-900/30">
                                    {params[p.name] !== undefined
                                      ? typeof params[p.name] === "boolean"
                                        ? params[p.name]
                                          ? "ON"
                                          : "OFF"
                                        : !isNaN(Number(params[p.name]))
                                          ? Number(params[p.name]).toFixed((p.step || 1) < 0.1 ? 2 : 1)
                                          : String(params[p.name])
                                      : p.default}
                                  </span>
                                </div>

                                {p.type === "slider" ? (
                                  <div className="flex items-center gap-2.5 mt-1.5">
                                    <input
                                      type="range"
                                      min={p.min}
                                      max={p.max}
                                      step={p.step}
                                      value={params[p.name] !== undefined ? (params[p.name] as number) : (p.default as number)}
                                      onChange={(e) =>
                                        setParams((prev) => ({
                                          ...prev,
                                          [p.name]: parseFloat(e.target.value),
                                        }))
                                      }
                                      className="flex-1 accent-indigo-500 h-1 bg-neutral-800 rounded-lg appearance-none outline-none cursor-ew-resize"
                                    />
                                  </div>
                                ) : (
                                  <div className="flex items-center mt-1.5">
                                    <button
                                      onClick={() =>
                                        setParams((prev) => ({
                                          ...prev,
                                          [p.name]: !prev[p.name],
                                        }))
                                      }
                                      className={`text-xs px-3 py-1 rounded-md font-medium border cursor-pointer transition-all ${
                                        params[p.name]
                                          ? "bg-indigo-600 border-indigo-500 text-white"
                                          : "bg-neutral-900 border-neutral-800 text-neutral-400 hover:border-neutral-700"
                                      }`}
                                    >
                                      {params[p.name] ? "Toggle Active" : "Toggle Inactive"}
                                    </button>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        );
                      })()}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>}
            </section>

            {/* Right Side: Scientific Explanations Panel & History (4 cols) */}
            <section className="lg:col-span-4 flex flex-col gap-5">
              
              {/* Scientific Explanation Block */}
              <div className="glass-panel rounded-xl overflow-hidden border border-neutral-900 flex flex-col shadow-xl">
                <div className="px-4 py-3 bg-[#0d0d14] border-b border-neutral-900 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-neutral-300 font-display font-medium tracking-wider uppercase">
                    <BookOpen className="w-4 h-4 text-emerald-400" />
                    Scientific Grounding
                  </div>
                  <span className="text-[10px] text-emerald-400 bg-emerald-950/30 border border-emerald-900/30 px-1.5 py-0.5 rounded font-mono">
                    Theories & Equations
                  </span>
                </div>

                <div className="p-5 max-h-[780px] overflow-y-auto font-sans text-sm leading-relaxed text-zinc-300 space-y-4 scrollbar-thin">
                  <h3 className="text-lg font-display font-bold text-neutral-100 border-b border-neutral-900 pb-2">
                    {simulation.topic}
                  </h3>
                  
                  {/* Markdown Content with Professional KaTeX Math support */}
                  <div className="markdown-body text-xs leading-relaxed text-neutral-300 space-y-4 select-text">
                    <MathMarkdown content={simulation.explanation} />
                  </div>

                  {/* ── theoryData: Concept & Formula ── */}
                  {simulation.theoryData?.conceptAndFormula && (
                    <div className="mt-4 p-3.5 bg-emerald-950/15 border border-emerald-900/30 rounded-lg space-y-1.5">
                      <div className="flex items-center gap-1.5 text-[10px] font-display font-semibold uppercase tracking-wider text-emerald-400 mb-2">
                        <BookOpen className="w-3.5 h-3.5" />
                        Concept &amp; Formula
                      </div>
                      <div className="markdown-body text-xs leading-relaxed text-neutral-300 select-text">
                        <MathMarkdown content={simulation.theoryData.conceptAndFormula} />
                      </div>
                    </div>
                  )}

                  {/* ── theoryData: Step-by-Step Derivation ── */}
                  {simulation.theoryData?.derivation && (
                    <div className="mt-3 p-3.5 bg-indigo-950/15 border border-indigo-900/30 rounded-lg space-y-1.5">
                      <div className="flex items-center gap-1.5 text-[10px] font-display font-semibold uppercase tracking-wider text-indigo-400 mb-2">
                        <Sparkles className="w-3.5 h-3.5" />
                        Step-by-Step Derivation
                      </div>
                      <div className="markdown-body text-xs leading-relaxed text-neutral-300 select-text">
                        <MathMarkdown content={simulation.theoryData.derivation} />
                      </div>
                    </div>
                  )}

                  {/* ── theoryData: Real-Life Applications ── */}
                  {simulation.theoryData?.realLifeApplications?.length > 0 && (
                    <div className="mt-3 p-3.5 bg-sky-950/15 border border-sky-900/30 rounded-lg space-y-2">
                      <div className="flex items-center gap-1.5 text-[10px] font-display font-semibold uppercase tracking-wider text-sky-400 mb-2">
                        <Lightbulb className="w-3.5 h-3.5" />
                        Real-Life Applications
                      </div>
                      <ul className="space-y-1.5">
                        {simulation.theoryData.realLifeApplications.map((app: string, i: number) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-neutral-300 leading-relaxed">
                            <span className="mt-0.5 w-4 h-4 shrink-0 rounded-full bg-sky-900/40 border border-sky-800/40 flex items-center justify-center text-[9px] font-bold text-sky-400">
                              {i + 1}
                            </span>
                            {app}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* ── theoryData: Practice Questions ── */}
                  {simulation.theoryData?.practiceQuestions?.length > 0 && (
                    <div className="mt-3 p-3.5 bg-violet-950/15 border border-violet-900/30 rounded-lg space-y-3">
                      <div className="flex items-center gap-1.5 text-[10px] font-display font-semibold uppercase tracking-wider text-violet-400 mb-2">
                        <HelpCircle className="w-3.5 h-3.5" />
                        Practice Questions
                      </div>
                      {simulation.theoryData.practiceQuestions.map((q: { question: string; answer: string }, i: number) => (
                        <div key={i} className="space-y-1.5">
                          <p className="text-xs font-semibold text-neutral-200 leading-relaxed">
                            Q{i + 1}. {q.question}
                          </p>
                          <div className="pl-3 border-l-2 border-violet-700/50 text-xs text-neutral-400 leading-relaxed markdown-body select-text">
                            <MathMarkdown content={q.answer} />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Interaction help reminder */}
                  {simulation.controlsGuide && (
                    <div className="mt-4 p-3 bg-indigo-950/20 border border-indigo-900/30 rounded-lg text-[11px] text-indigo-300 leading-normal flex gap-2">
                      <HelpCircle className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block mb-0.5 text-indigo-200">How to Interact</span>
                        {simulation.controlsGuide}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Search History caching shelf */}
              <div className="glass-panel p-4 rounded-xl border border-neutral-900 flex flex-col gap-3">
                <div className="flex items-center justify-between border-b border-neutral-900 pb-2">
                  <div className="flex items-center gap-1.5 text-xs text-neutral-300 font-display font-semibold uppercase tracking-wider">
                    <History className="w-4 h-4 text-sky-400" />
                    Simulation Archive
                  </div>
                  {history.length > 0 && (
                    <button
                      onClick={async () => {
                        setHistory([]);
                        localStorage.removeItem("three_sec_history");
                        try {
                          await fetch("/api/clear-cache", { method: "POST" });
                        } catch (err) {
                          console.error("Failed to clear server side cache:", err);
                        }
                      }}
                      className="p-1 hover:text-red-400 text-neutral-500 rounded transition-colors cursor-pointer"
                      title="Clear local archives and server caches"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {history.length > 0 ? (
                  <div className="flex flex-col gap-1.5 max-h-[220px] overflow-y-auto scrollbar-thin">
                    {history.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => {
                          setSimulation(item.simulation);
                          setCopied(false);
                          setErrorMessage(null);
                        }}
                        className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between group text-xs ${
                          simulation.topic.toLowerCase() === item.topic.toLowerCase()
                            ? "bg-indigo-950/20 border-indigo-500/30 text-indigo-200 font-medium"
                            : "bg-neutral-950/40 border-neutral-900 hover:border-neutral-800 hover:bg-neutral-950 text-neutral-400"
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="text-zinc-500 font-mono text-[10px] group-hover:text-zinc-400">
                            {item.timestamp}
                          </span>
                          <span className="truncate group-hover:text-neutral-200">
                            {item.topic}
                          </span>
                        </div>
                        <button
                          onClick={(e) => deleteHistoryItem(item.id, e)}
                          className="p-1 text-neutral-600 hover:text-red-400 hover:bg-red-500/10 rounded transition-all opacity-0 group-hover:opacity-100"
                          title="Delete archive item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-6 text-center text-xs text-neutral-500 flex flex-col items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-neutral-600" />
                    <p>No concepts generated yet.</p>
                    <p className="text-[10px] leading-relaxed max-w-[200px] text-neutral-600">
                      Try typing "Eigenvalues orbital trajectories" or "Quantum probability node" in the search bar above!
                    </p>
                  </div>
                )}
              </div>

            </section>
          </main>

          {/* User Profile Modal */}
          <UserProfileModal
            isOpen={isProfileOpen}
            onClose={() => setIsProfileOpen(false)}
            email={email}
            history={history}
            onClearHistory={() => {
              setHistory([]);
              localStorage.setItem("three_sec_history", JSON.stringify([]));
            }}
            onSelectHistory={(item) => {
              setSimulation(item.simulation);
              setParams({});
              setActiveTab("render");
            }}
            onSignOut={handleSignOut}
          />

          {/* Styled Footer */}
          <footer className="mt-auto border-t border-neutral-900/60 py-6 text-center text-xs text-neutral-500">
            <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-[11px] tracking-wide">
              <p>
                Designed & Developed by <span className="text-cyan-400 font-bold">Raushan Kumar</span> <span className="text-neutral-700">|</span> <span className="text-neutral-400">Vertex</span>
              </p>
              <div className="flex gap-4">
                <a
                  href="https://threejs.org"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-cyan-400 transition-colors flex items-center gap-1 text-neutral-500 hover:text-neutral-300"
                >
                  Three.js docs
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </footer>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
